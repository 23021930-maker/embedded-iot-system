COMPONENT_SRCDIRS := . \
                     task1read \
                     task1read/readhc \
                     task2check \
                     task3local \
                     task4wifi \
                     task5pub \
                     task6res

COMPONENT_ADD_INCLUDEDIRS := . \
                              task1read \
                              task1read/readhc \
                              task2check \
                              task3local \
                              task4wifi \
                              task5pub \
                              task6res
