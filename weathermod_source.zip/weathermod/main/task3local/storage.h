#ifndef STORAGE_H
#define STORAGE_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#define SPIFFS_BASE_PATH        "/spiffs"
#define SPIFFS_FILE_PATH        "/spiffs/weather.bin"

#define STORAGE_MAX_SIZE        (1024 * 1024)
#define STORAGE_LIMIT_SIZE      ((STORAGE_MAX_SIZE * 80) / 100)

/* Status:
 * bit 7 = RAD error
 * bit 6 = RAIN error
 * bit 5 = HUMID error
 * bit 4 = TEMP error
 * bit 3 = WIND error
 * bit 2 = RETRY
 * bit 1 = LAST (transmit-only; never stored)
 * bit 0 = SENT
 */
#define STATUS_RETRY_BIT        (1 << 2)
#define STATUS_LAST_BIT         (1 << 1)
#define STATUS_SENT_BIT         (1 << 0)

typedef struct __attribute__((packed))
{
    uint32_t id;
    float rad;
    float rai;
    float humid;
    float temp;
    float wind;
    uint8_t status;
} WeatherRecord;

bool storage_init(void);
uint32_t storage_get_next_id(void);
void storage_increment_id(void);
bool storage_save(const WeatherRecord *record);
int storage_read_unsent_batch(WeatherRecord *records, int max_records);
bool storage_update_status(uint32_t id, uint8_t status);
size_t storage_count_sent(void);
bool storage_delete_sent(void);
bool storage_lock(TickType_t timeout);
void storage_unlock(void);

#endif

