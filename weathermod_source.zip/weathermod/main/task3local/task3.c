#include "task3.h"
#include "storage.h"
#include "statuscheck.h"
#include "esp_log.h"

extern QueueHandle_t processed_queue;

static const char *TAG = "TASK3";

static void task3_check_sent_cleanup(void)
{
    size_t sent_count =
        storage_count_sent();

    size_t max_records =
        STORAGE_MAX_SIZE /
        sizeof(WeatherRecord);

    size_t sent_threshold =
        (max_records * 50) / 100;

    if (sent_threshold == 0)
        sent_threshold = 1;

    if (sent_count >= sent_threshold)
    {
        ESP_LOGW(
            TAG,
            "SENT reached 50%% (%u/%u) -> deleting SENT",
            (unsigned int)sent_count,
            (unsigned int)sent_threshold
        );

        if (storage_delete_sent())
        {
            ESP_LOGI(
                TAG,
                "SENT records deleted successfully"
            );
        }
        else
        {
            ESP_LOGE(
                TAG,
                "Failed to delete SENT records"
            );
        }
    }
}

void task3_storage(void *pvParameters)
{
    (void)pvParameters;
    processed_weather_t input;
    WeatherRecord record;

    while (1)
    {
        if (xQueueReceive(processed_queue, &input, portMAX_DELAY) == pdTRUE)
        {
            record.id    = storage_get_next_id();
            record.rad   = input.radiation;
            record.rai   = input.rain;
            record.humid = input.humidity;
            record.temp  = input.temperature;
            record.wind  = input.windspeed;

            /* LAST is transmit-only; SENT is zero for a new record. */
            record.status = input.status;
            record.status &= (uint8_t)~STATUS_LAST_BIT;
            record.status &= (uint8_t)~STATUS_SENT_BIT;

            if (storage_save(&record))
            {
                storage_increment_id();

                ESP_LOGI(
                    TAG,
                    "Saved ID=%lu",
                    (unsigned long)record.id
                );

                /*
                 * Kiểm tra số lượng record SENT ngay sau khi
                 * Task3 lưu một record mới thành công.
                 */
                task3_check_sent_cleanup();
            }
            else
            {
                ESP_LOGE(TAG, "Save ID=%lu failed", (unsigned long)record.id);
            }
        }
    }
}

