#include "storage.h"

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

#include "esp_log.h"
#include "esp_spiffs.h"


static const char *TAG = "STORAGE";


/*
 * =========================================================
 * ID tiếp theo
 * =========================================================
 */

static uint32_t next_id = 1;


/*
 * =========================================================
 * MUTEX CHUNG
 * =========================================================
 */

static SemaphoreHandle_t storage_mutex = NULL;


/*
 * =========================================================
 * Load ID tiếp theo
 * =========================================================
 */

static void storage_load_next_id(void)
{
    FILE *file = fopen(
        SPIFFS_FILE_PATH,
        "rb"
    );


    if (file == NULL)
    {
        next_id = 1;

        ESP_LOGI(TAG,
                 "No existing data");

        ESP_LOGI(TAG,
                 "Next ID = %lu",
                 (unsigned long)next_id);

        return;
    }


    /*
     * Đi tới record cuối
     */

    if (fseek(
            file,
            -(long)sizeof(WeatherRecord),
            SEEK_END
        ) != 0)
    {
        fclose(file);

        next_id = 1;

        return;
    }


    WeatherRecord last_record;


    /*
     * Đọc record cuối
     */

    if (fread(
            &last_record,
            sizeof(WeatherRecord),
            1,
            file
        ) == 1)
    {
        next_id = last_record.id + 1;

        ESP_LOGI(TAG,
                 "Last ID = %lu",
                 (unsigned long)last_record.id);

        ESP_LOGI(TAG,
                 "Next ID = %lu",
                 (unsigned long)next_id);
    }
    else
    {
        next_id = 1;
    }


    fclose(file);
}


/*
 * =========================================================
 * INIT
 * =========================================================
 */

bool storage_init(void)
{
    /*
     * Tạo mutex
     */

    storage_mutex = xSemaphoreCreateMutex();

    if (storage_mutex == NULL)
    {
        ESP_LOGE(TAG,
                 "Cannot create storage mutex");

        return false;
    }


    /*
     * SPIFFS config
     */

    esp_vfs_spiffs_conf_t conf =
    {
        .base_path = SPIFFS_BASE_PATH,

        .partition_label = NULL,

        .max_files = 5,

        .format_if_mount_failed = true
    };


    esp_err_t ret =
        esp_vfs_spiffs_register(&conf);


    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "SPIFFS mount failed: %s",
            esp_err_to_name(ret)
        );

        vSemaphoreDelete(storage_mutex);

        storage_mutex = NULL;

        return false;
    }


    /*
     * Kiểm tra kích thước record
     */

    ESP_LOGI(
        TAG,
        "WeatherRecord size = %u bytes",
        (unsigned int)sizeof(WeatherRecord)
    );


    /*
     * Load ID
     */

    storage_load_next_id();


    /*
     * SPIFFS info
     */

    size_t total = 0;
    size_t used = 0;


    ret = esp_spiffs_info(
        NULL,
        &total,
        &used
    );


    if (ret == ESP_OK)
    {
        ESP_LOGI(
            TAG,
            "SPIFFS total = %u bytes",
            (unsigned int)total
        );

        ESP_LOGI(
            TAG,
            "SPIFFS used = %u bytes",
            (unsigned int)used
        );
    }


    return true;
}


/*
 * =========================================================
 * LOCK
 * =========================================================
 */

bool storage_lock(TickType_t timeout)
{
    if (storage_mutex == NULL)
    {
        return false;
    }


    return (
        xSemaphoreTake(
            storage_mutex,
            timeout
        ) == pdTRUE
    );
}


/*
 * =========================================================
 * UNLOCK
 * =========================================================
 */

void storage_unlock(void)
{
    if (storage_mutex != NULL)
    {
        xSemaphoreGive(storage_mutex);
    }
}


/*
 * =========================================================
 * GET NEXT ID
 * =========================================================
 */

uint32_t storage_get_next_id(void)
{
    return next_id;
}


/*
 * =========================================================
 * INCREMENT ID
 * =========================================================
 */

void storage_increment_id(void)
{
    next_id++;
}


/*
 * =========================================================
 * FILE SIZE
 * =========================================================
 */

static long storage_get_file_size(void)
{
    FILE *file = fopen(
        SPIFFS_FILE_PATH,
        "rb"
    );


    if (file == NULL)
    {
        return 0;
    }


    fseek(
        file,
        0,
        SEEK_END
    );


    long size = ftell(file);


    fclose(file);


    return size;
}


/*
 * =========================================================
 * DELETE OLDEST 50%
 * =========================================================
 */

static bool storage_delete_oldest_50_percent(void)
{
    FILE *source =
        fopen(
            SPIFFS_FILE_PATH,
            "rb"
        );


    if (source == NULL)
    {
        return true;
    }


    /*
     * File size
     */

    fseek(
        source,
        0,
        SEEK_END
    );


    long file_size =
        ftell(source);


    if (file_size <= 0)
    {
        fclose(source);

        return true;
    }


    /*
     * Record count
     */

    size_t record_count =
        (size_t)file_size /
        sizeof(WeatherRecord);


    if (record_count < 2)
    {
        fclose(source);

        return true;
    }


    /*
     * Delete 50%
     */

    size_t delete_count =
        record_count / 2;


    size_t remain_count =
        record_count -
        delete_count;


    ESP_LOGW(
        TAG,
        "Delete %u oldest records",
        (unsigned int)delete_count
    );


    /*
     * Temporary file
     */

    FILE *temp =
        fopen(
            "/spiffs/weather.tmp",
            "wb"
        );


    if (temp == NULL)
    {
        fclose(source);

        ESP_LOGE(
            TAG,
            "Cannot create temporary file"
        );

        return false;
    }


    /*
     * Bỏ qua record cũ
     */

    long offset =
        (long)(
            delete_count *
            sizeof(WeatherRecord)
        );


    if (fseek(
            source,
            offset,
            SEEK_SET
        ) != 0)
    {
        fclose(source);
        fclose(temp);

        remove(
            "/spiffs/weather.tmp"
        );

        return false;
    }


    WeatherRecord record;


    /*
     * Copy phần còn lại
     */

    for (size_t i = 0;
         i < remain_count;
         i++)
    {
        if (fread(
                &record,
                sizeof(WeatherRecord),
                1,
                source
            ) != 1)
        {
            ESP_LOGE(
                TAG,
                "Read record failed"
            );

            fclose(source);
            fclose(temp);

            remove(
                "/spiffs/weather.tmp"
            );

            return false;
        }


        if (fwrite(
                &record,
                sizeof(WeatherRecord),
                1,
                temp
            ) != 1)
        {
            ESP_LOGE(
                TAG,
                "Write temporary record failed"
            );

            fclose(source);
            fclose(temp);

            remove(
                "/spiffs/weather.tmp"
            );

            return false;
        }
    }


    fflush(temp);


    fclose(source);
    fclose(temp);


    /*
     * Xóa file cũ
     */

    if (remove(
            SPIFFS_FILE_PATH
        ) != 0)
    {
        ESP_LOGE(
            TAG,
            "Cannot remove old file"
        );

        remove(
            "/spiffs/weather.tmp"
        );

        return false;
    }


    /*
     * Rename
     */

    if (rename(
            "/spiffs/weather.tmp",
            SPIFFS_FILE_PATH
        ) != 0)
    {
        ESP_LOGE(
            TAG,
            "Cannot rename temporary file"
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "Remaining records = %u",
        (unsigned int)remain_count
    );


    return true;
}


/*
 * =========================================================
 * CHECK STORAGE LIMIT
 * =========================================================
 */

static bool storage_check_limit(void)
{
    long file_size =
        storage_get_file_size();


    /*
     * Chưa đạt 80%
     */

    if (file_size < STORAGE_LIMIT_SIZE)
    {
        return true;
    }


    ESP_LOGW(
        TAG,
        "Storage reached %.2f%%",
        ((float)file_size /
         (float)STORAGE_MAX_SIZE) *
        100.0f
    );


    /*
     * Xóa 50% record cũ
     */

    return storage_delete_oldest_50_percent();
}


/*
 * =========================================================
 * SAVE
 * =========================================================
 */

bool storage_save(
    const WeatherRecord *record
)
{
    if (record == NULL)
    {
        return false;
    }


    /*
     * LOCK
     */

    if (!storage_lock(portMAX_DELAY))
    {
        ESP_LOGE(
            TAG,
            "Cannot lock storage"
        );

        return false;
    }


    bool success = false;


    /*
     * Kiểm tra giới hạn
     */

    if (!storage_check_limit())
    {
        ESP_LOGE(
            TAG,
            "Storage cleanup failed"
        );

        goto cleanup;
    }


    /*
     * Append binary
     */

    FILE *file =
        fopen(
            SPIFFS_FILE_PATH,
            "ab"
        );


    if (file == NULL)
    {
        ESP_LOGE(
            TAG,
            "Cannot open weather.bin"
        );

        goto cleanup;
    }


    /*
     * Ghi record
     */

    size_t result =
        fwrite(
            record,
            sizeof(WeatherRecord),
            1,
            file
        );


    fflush(file);

    fclose(file);


    if (result != 1)
    {
        ESP_LOGE(
            TAG,
            "Write record failed"
        );

        goto cleanup;
    }


    ESP_LOGI(
        TAG,
        "Saved ID = %lu",
        (unsigned long)record->id
    );


    success = true;


cleanup:

    storage_unlock();

    return success;
}


/*
 * =========================================================
 * READ UNSENT BATCH
 * =========================================================
 *
 * Đọc FIFO từ đầu file.
 *
 * Chỉ lấy record:
 *
 * SENT = 0
 */

int storage_read_unsent_batch(
    WeatherRecord *records,
    int max_records
)
{
    if (records == NULL ||
        max_records <= 0)
    {
        return -1;
    }


    if (!storage_lock(portMAX_DELAY))
    {
        return -1;
    }


    FILE *file =
        fopen(
            SPIFFS_FILE_PATH,
            "rb"
        );


    if (file == NULL)
    {
        storage_unlock();

        return 0;
    }


    int count = 0;

    WeatherRecord record;


    while (
        count < max_records &&
        fread(
            &record,
            sizeof(WeatherRecord),
            1,
            file
        ) == 1
    )
    {
        /*
         * SENT = 0
         */

        if ((record.status &
             STATUS_SENT_BIT) == 0)
        {
            records[count] = record;

            count++;
        }
    }


    fclose(file);


    storage_unlock();


//    ESP_LOGI(
  //      TAG,
    //    "Read %d unsent records",
      //  count
   // );


    return count;
}


/*
 * =========================================================
 * UPDATE STATUS
 * =========================================================
 */

bool storage_update_status(
    uint32_t id,
    uint8_t status
)
{
    if (!storage_lock(portMAX_DELAY))
    {
        return false;
    }


    FILE *file =
        fopen(
            SPIFFS_FILE_PATH,
            "r+b"
        );


    if (file == NULL)
    {
        storage_unlock();

        return false;
    }


    WeatherRecord record;

    bool found = false;


    while (
        fread(
            &record,
            sizeof(WeatherRecord),
            1,
            file
        ) == 1
    )
    {
        if (record.id == id)
        {
            /*
             * Quay lại đầu record
             */

            if (fseek(
                    file,
                    -(long)sizeof(WeatherRecord),
                    SEEK_CUR
                ) != 0)
            {
                fclose(file);

                storage_unlock();

                return false;
            }


            record.status = status;


            if (fwrite(
                    &record,
                    sizeof(WeatherRecord),
                    1,
                    file
                ) != 1)
            {
                fclose(file);

                storage_unlock();

                return false;
            }


            fflush(file);

            found = true;

            break;
        }
    }


    fclose(file);


    storage_unlock();


    if (found)
    {
        ESP_LOGI(
            TAG,
            "Update status ID=%lu status=0x%02X",
            (unsigned long)id,
            status
        );
    }


    return found;
}


/*
 * =========================================================
 * COUNT SENT
 * =========================================================
 */

size_t storage_count_sent(void)
{
    if (!storage_lock(portMAX_DELAY))
    {
        return 0;
    }


    FILE *file =
        fopen(
            SPIFFS_FILE_PATH,
            "rb"
        );


    if (file == NULL)
    {
        storage_unlock();

        return 0;
    }


    size_t count = 0;

    WeatherRecord record;


    while (
        fread(
            &record,
            sizeof(WeatherRecord),
            1,
            file
        ) == 1
    )
    {
        if (record.status &
            STATUS_SENT_BIT)
        {
            count++;
        }
    }


    fclose(file);


    storage_unlock();


    return count;
}


/*
 * =========================================================
 * DELETE SENT RECORDS
 * =========================================================
 */

bool storage_delete_sent(void)
{
    if (!storage_lock(portMAX_DELAY))
    {
        return false;
    }


    FILE *source =
        fopen(
            SPIFFS_FILE_PATH,
            "rb"
        );


    if (source == NULL)
    {
        storage_unlock();

        return true;
    }


    FILE *temp =
        fopen(
            "/spiffs/weather.tmp",
            "wb"
        );


    if (temp == NULL)
    {
        fclose(source);

        storage_unlock();

        return false;
    }


    WeatherRecord record;

    size_t deleted = 0;
    size_t remained = 0;


    while (
        fread(
            &record,
            sizeof(WeatherRecord),
            1,
            source
        ) == 1
    )
    {
        /*
         * SENT = 1
         * -> bỏ record
         */

        if (record.status &
            STATUS_SENT_BIT)
        {
            deleted++;

            continue;
        }


        /*
         * SENT = 0
         * -> giữ lại
         */

        if (fwrite(
                &record,
                sizeof(WeatherRecord),
                1,
                temp
            ) != 1)
        {
            fclose(source);
            fclose(temp);

            remove(
                "/spiffs/weather.tmp"
            );

            storage_unlock();

            return false;
        }


        remained++;
    }


    fflush(temp);


    fclose(source);
    fclose(temp);


    /*
     * Xóa file cũ
     */

    if (remove(
            SPIFFS_FILE_PATH
        ) != 0)
    {
        remove(
            "/spiffs/weather.tmp"
        );

        storage_unlock();

        return false;
    }


    /*
     * Rename
     */

    if (rename(
            "/spiffs/weather.tmp",
            SPIFFS_FILE_PATH
        ) != 0)
    {
        storage_unlock();

        return false;
    }


    ESP_LOGI(
        TAG,
        "Deleted SENT = %u, remaining = %u",
        (unsigned int)deleted,
        (unsigned int)remained
    );


    storage_unlock();


    return true;
}
