#ifndef TASK6_H
#define TASK6_H

#include "esp_err.h"
#include "freertos/FreeRTOS.h"

typedef enum
{
    TASK6_CMD_CHECK = 0,
    TASK6_CMD_RESET
} task6_command_t;

typedef enum
{
    TASK1_RESET_DONE = 0,
    TASK1_RESET_FAILED
} task1_reset_result_t;

esp_err_t task6_init(void);
void task6_task(void *pvParameters);
esp_err_t task6_send_command(task6_command_t command);


#endif

