#include "task6.h"

#include "wifi_mqtt.h"
#include "sensortask.h"

#include "esp_log.h"
#include "mqtt_client.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

static const char *TAG = "TASK6";

#define TASK6_QUEUE_LENGTH      8
#define TASK6_RESET_WAIT_MS     10000

#define PING_CHECK_ACK_TOPIC    "Weather/ping/check/ACK"
#define PING_RESET_ACK_TOPIC    "Weather/ping/resetACK"

static QueueHandle_t task6_cmd_queue = NULL;


/* =========================================================
 * Task6 initialization
 * ========================================================= */

esp_err_t task6_init(void)
{
    if (task6_cmd_queue == NULL)
    {
        task6_cmd_queue = xQueueCreate(
            TASK6_QUEUE_LENGTH,
            sizeof(task6_command_t));

        if (task6_cmd_queue == NULL)
        {
            ESP_LOGE(TAG, "Cannot create Task6 command queue");
            return ESP_ERR_NO_MEM;
        }
    }

    return ESP_OK;
}


/* =========================================================
 * Send command to Task6
 * ========================================================= */

esp_err_t task6_send_command(task6_command_t command)
{
    if (task6_cmd_queue == NULL)
    {
        ESP_LOGW(TAG, "Task6 queue is not initialized");
        return ESP_ERR_INVALID_STATE;
    }

    if (xQueueSend(
            task6_cmd_queue,
            &command,
            0) != pdPASS)
    {
        ESP_LOGW(TAG, "Task6 command queue FULL");
        return ESP_ERR_TIMEOUT;
    }

    return ESP_OK;
}


/* =========================================================
 * Publish ACK to MQTT broker
 * ========================================================= */

static void task6_publish(const char *topic)
{
    esp_mqtt_client_handle_t client = get_mqtt_client();

    if (client == NULL || !mqtt_is_connected())
    {
        ESP_LOGW(
            TAG,
            "Cannot publish %s: MQTT not connected",
            topic);

        return;
    }

    int msg_id = esp_mqtt_client_publish(
        client,
        topic,
        "1",
        1,
        1,
        0);

    if (msg_id < 0)
    {
        ESP_LOGE(TAG, "Publish failed: %s", topic);
    }
    else
    {
        printf("\n[TASK6] MQTT SEND\n");
        printf("Topic   : %s\n", topic);
        printf("Payload : 1\n");
        printf("Msg ID  : %d\n", msg_id);

        ESP_LOGI(TAG, "Published ACK: %s", topic);
    }
}


/* =========================================================
 * Handle RESET command
 * ========================================================= */

static void task6_handle_reset(void)
{
    /*
     * Xóa kết quả cũ trước khi gửi RESET mới.
     *
     * 0 = chưa reset thành công
     * 1 = reset thành công
     */
    sensor_reset_result = 0;

    ESP_LOGI(TAG, "Reset result flag cleared");


    /*
     * Gửi event RESET = 1 cho SensorTask
     */
    if (sensor_task_request_reset() != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "Cannot send RESET event to SensorTask");

        return;
    }

    ESP_LOGI(
        TAG,
        "RESET event sent to SensorTask");


    /*
     * Chờ SensorTask thực hiện:
     *
     * sensor_reset()
     *      ->
     * sensor_init()
     *
     * Task6 không nhận queue kết quả nữa.
     *
     * Sau khi Task1 xử lý xong:
     *
     * thành công -> sensor_reset_result = 1
     * thất bại  -> sensor_reset_result = 0
     */
    ESP_LOGI(
        TAG,
        "Waiting %d seconds for SensorTask reset",
        TASK6_RESET_WAIT_MS / 1000);

    vTaskDelay(
        pdMS_TO_TICKS(TASK6_RESET_WAIT_MS));


    /*
     * Kiểm tra kết quả reset
     */
    if (sensor_reset_result == 1)
    {
        ESP_LOGI(
            TAG,
            "Sensor reset SUCCESS");

        /*
         * Gửi RESET ACK cho broker
         *
         * Topic:
         * Weather/ping/resetACK
         *
         * Payload:
         * "1"
         */
        task6_publish(PING_RESET_ACK_TOPIC);


        /*
         * Reset flag về 0 sau khi đã xử lý
         */
        sensor_reset_result = 0;

        ESP_LOGI(
            TAG,
            "Reset result flag cleared");
    }
    else
    {
        /*
         * Reset thất bại
         *
         * Không gửi resetACK
         */
        ESP_LOGE(
            TAG,
            "Sensor reset FAILED");

        /*
         * Đảm bảo flag vẫn về 0
         */
        sensor_reset_result = 0;
    }
}


/* =========================================================
 * Task6
 * ========================================================= */

void task6_task(void *pvParameters)
{
    (void)pvParameters;

    ESP_LOGI(TAG, "Task 6 started");

    while (1)
    {
        task6_command_t command;


        /*
         * Chờ command từ MQTT
         */
        if (xQueueReceive(
                task6_cmd_queue,
                &command,
                portMAX_DELAY) != pdPASS)
        {
            continue;
        }


        switch (command)
        {
            /* ---------------------------------------------
             * CHECK
             * --------------------------------------------- */

            case TASK6_CMD_CHECK:

                ESP_LOGI(
                    TAG,
                    "CHECK command received");

                /*
                 * Gửi:
                 *
                 * Weather/ping/check/ACK
                 *
                 * Payload = "1"
                 */
                task6_publish(
                    PING_CHECK_ACK_TOPIC);

                break;


            /* ---------------------------------------------
             * RESET
             * --------------------------------------------- */

            case TASK6_CMD_RESET:

                ESP_LOGI(
                    TAG,
                    "RESET command received");

                task6_handle_reset();

                break;


            /* ---------------------------------------------
             * UNKNOWN
             * --------------------------------------------- */

            default:

                ESP_LOGW(
                    TAG,
                    "Unknown command: %d",
                    command);

                break;
        }
    }
}
