#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#include "esp_log.h"
#include "esp_spiffs.h"

#include "sensor.h"
#include "sensortask.h"

#include "statuscheck.h"

#include "wifi_mqtt.h"

#include "task3.h"
#include "storage.h"

#include "task5.h"
#include "task6.h"


static const char *TAG = "MAIN";


/* =========================================================
 * processed_queue
 *
 * Task2 -> Task3
 * ========================================================= */

extern QueueHandle_t processed_queue;


/* =========================================================
 * Task2
 * ========================================================= */

extern void task2_status_check(void *pvParameters);


/* =========================================================
 * Task4
 * ========================================================= */

extern void task4_wifi_mqtt(void *pvParameters);


/* =========================================================
 * In float với 2 chữ số thập phân
 *
 * KHÔNG dùng printf("%.2f")
 * ========================================================= */

static void print_float_2(
    const char *name,
    float value,
    const char *unit
)
{
    int value_x100 = (int)(value * 100.0f);

    int integer_part = value_x100 / 100;
    int decimal_part = value_x100 % 100;

    if (decimal_part < 0)
    {
        decimal_part = -decimal_part;
    }

    printf(
        "%-12s: %d.%02d %s\n",
        name,
        integer_part,
        decimal_part,
        unit
    );
}


/* =========================================================
 * In 1 WeatherRecord
 * ========================================================= */

static void print_weather_record(
    WeatherRecord *record,
    int index
)
{
    printf("\n");
    printf("Record #%d\n", index);

    printf(
        "ID           : %lu\n",
        (unsigned long)record->id
    );

    print_float_2(
        "Radiation",
        record->rad,
        "MJ/m2"
    );

    print_float_2(
        "Rain",
        record->rai,
        "mm"
    );

    print_float_2(
        "Humidity",
        record->humid,
        "%"
    );

    print_float_2(
        "Temperature",
        record->temp,
        "C"
    );

    print_float_2(
        "Wind speed",
        record->wind,
        "m/s"
    );

    printf(
        "Status       : 0x%02X\n",
        record->status
    );
}


/* =========================================================
 * So sánh danh sách record cũ và mới
 *
 * Trả về:
 *     1 = có record mới
 *     0 = không có record mới
 * ========================================================= */

static int storage_has_new_record(
    WeatherRecord *old_records,
    int old_count,
    WeatherRecord *new_records,
    int new_count
)
{
    for (int i = 0; i < new_count; i++)
    {
        int found = 0;

        for (int j = 0; j < old_count; j++)
        {
            if (new_records[i].id == old_records[j].id)
            {
                found = 1;
                break;
            }
        }

        if (!found)
        {
            return 1;
        }
    }

    return 0;
}


/* =========================================================
 * STORAGE MONITOR
 *
 * 
 *  in bảng SPIFFS khi phát hiện có record mới.
 * ========================================================= */

static void storage_monitor_task(void *pvParameters)
{
    (void)pvParameters;

    WeatherRecord old_records[50];
    WeatherRecord new_records[50];

    int old_count = 0;

    memset(
        old_records,
        0,
        sizeof(old_records)
    );

    while (1)
    {
        vTaskDelay(
            pdMS_TO_TICKS(1000)
        );

        int new_count =
            storage_read_unsent_batch(
                new_records,
                50
            );

        if (new_count < 0)
        {
            ESP_LOGE(
                TAG,
                "Read SPIFFS FAILED"
            );

            continue;
        }


        /*
         * Lần đầu chạy:
         *
         * Chỉ lưu trạng thái hiện tại,
         * không in bảng dữ liệu cũ.
         */
        if (old_count == 0)
        {
            memcpy(
                old_records,
                new_records,
                sizeof(WeatherRecord) * new_count
            );

            old_count = new_count;

            continue;
        }


        /*
         * Kiểm tra xem có record mới hay không.
         */
        if (
            storage_has_new_record(
                old_records,
                old_count,
                new_records,
                new_count
            )
        )
        {
            printf("\n");
            printf("========================================\n");
            printf("       NEW DATA STORED IN SPIFFS\n");
            printf("========================================\n");

           printf(
    		"Unsent records = %d\n",
    		new_count
		); 

            printf("----------------------------------------\n");


            for (int i = 0; i < new_count; i++)
            {
                print_weather_record(
                    &new_records[i],
                    i + 1
                );
            }


            printf("========================================\n");


            /*
             * Cập nhật snapshot
             */
            memcpy(
                old_records,
                new_records,
                sizeof(WeatherRecord) * new_count
            );

            old_count = new_count;
        }
        else
        {
            /*
             * Không có record mới.
             *
             * Tuy nhiên vẫn cập nhật snapshot
             * để xử lý trường hợp Task5 đã SENT
             * và Task3 xóa record.
             */
            memcpy(
                old_records,
                new_records,
                sizeof(WeatherRecord) * new_count
            );

            old_count = new_count;
        }
    }
}


/* =========================================================
 * APP MAIN
 * ========================================================= */

void app_main(void)
{
    /* =====================================================
     * 1. weather_queue
     *
     * Task1 -> Task2
     * ===================================================== */

    weather_queue =
        xQueueCreate(
            10,
            sizeof(weather_data_t)
        );

    if (weather_queue == NULL)
    {
        ESP_LOGE(
            TAG,
            "Create weather_queue FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "weather_queue created"
    );


    /* =====================================================
     * 2. processed_queue
     *
     * Task2 -> Task3
     * ===================================================== */

    processed_queue =
        xQueueCreate(
            10,
            sizeof(processed_weather_t)
        );

    if (processed_queue == NULL)
    {
        ESP_LOGE(
            TAG,
            "Create processed_queue FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "processed_queue created"
    );


    /* =====================================================
     * 3. sensor_event_queue
     *
     * QUAN TRỌNG:
     *
     * sensor_task_request_reset()
     * dùng xQueueOverwrite()
     *
     * => queue length = 1
     * ===================================================== */

    sensor_event_queue =
        xQueueCreate(
            1,
            sizeof(uint8_t)
        );

    if (sensor_event_queue == NULL)
    {
        ESP_LOGE(
            TAG,
            "Create sensor_event_queue FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "sensor_event_queue created (length = 1)"
    );


    /* =====================================================
     * 4. KHỞI TẠO SPIFFS
     * ===================================================== */

    ESP_LOGI(
        TAG,
        "Initializing SPIFFS..."
    );

    if (!storage_init())
    {
        ESP_LOGE(
            TAG,
            "SPIFFS initialization FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "SPIFFS initialization SUCCESS"
    );


    /* =====================================================
     * 5. SPIFFS INFORMATION
     * ===================================================== */

    size_t spiffs_total = 0;
    size_t spiffs_used = 0;

    esp_err_t spiffs_ret =
        esp_spiffs_info(
            NULL,
            &spiffs_total,
            &spiffs_used
        );

    if (spiffs_ret == ESP_OK)
    {
        printf("\n");
        printf("========================================\n");
        printf("           SPIFFS INFORMATION\n");
        printf("========================================\n");

        printf(
            "Total : %u bytes\n",
            (unsigned int)spiffs_total
        );

        printf(
            "Used  : %u bytes\n",
            (unsigned int)spiffs_used
        );

        printf(
            "Free  : %u bytes\n",
            (unsigned int)(
                spiffs_total - spiffs_used
            )
        );

        printf("========================================\n");
    }
    else
    {
        ESP_LOGE(
            TAG,
            "Cannot get SPIFFS information"
        );
    }


    /* =====================================================
     * 6. WiFi + MQTT
     * ===================================================== */

    ESP_LOGI(
        TAG,
        "Initializing WiFi + MQTT..."
    );

    if (wifi_mqtt_init() != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "WiFi + MQTT initialization FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "WiFi + MQTT initialized"
    );


    /* =====================================================
     * 7. INIT TASK5
     *
     * Task5:
     *     - publish Weather/data
     *     - nhận Weather/data/ACK
     *     - nhận ping/check
     *     - nhận ping/reset
     * ===================================================== */

    ESP_LOGI(
        TAG,
        "Initializing Task5..."
    );

    if (task5_init() != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "Task5 initialization FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "Task5 initialization SUCCESS"
    );


    /* =====================================================
     * 8. INIT TASK6
     *
     * Task6:
     *     - check
     *     - reset
     *     - gửi reset ACK
     * ===================================================== */

    ESP_LOGI(
        TAG,
        "Initializing Task6..."
    );

    if (task6_init() != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "Task6 initialization FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "Task6 initialization SUCCESS"
    );


    /* =====================================================
     * 9. TASK1 - SENSOR
     * ===================================================== */

    if (xTaskCreate(
            sensor_task,
            "SensorTask",
            4096,
            NULL,
            5,
            NULL
        ) != pdPASS)
    {
        ESP_LOGE(
            TAG,
            "Create SensorTask FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "SensorTask created"
    );


    /* =====================================================
     * 10. TASK2 - STATUS CHECK
     *
     * weather_queue
     *       ↓
     *     Task2
     *       ↓
     * processed_queue
     * ===================================================== */

    if (xTaskCreate(
            task2_status_check,
            "Task2",
            4096,
            NULL,
            5,
            NULL
        ) != pdPASS)
    {
        ESP_LOGE(
            TAG,
            "Create Task2 FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "Task2 created"
    );


    /* =====================================================
     * 11. TASK3 - STORAGE
     *
     * processed_queue
     *       ↓
     *     Task3
     *       ↓
     * SPIFFS /spiffs/weather.bin
     * ===================================================== */

    if (xTaskCreate(
            task3_storage,
            "Task3Storage",
            4096,
            NULL,
            5,
            NULL
        ) != pdPASS)
    {
        ESP_LOGE(
            TAG,
            "Create Task3Storage FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "Task3Storage created"
    );


    /* =====================================================
     * 12. SPIFFS MONITOR
     *
     * Chỉ in bảng khi có record mới.
     * ===================================================== */

    if (xTaskCreate(
            storage_monitor_task,
            "StorageMonitor",
            4096,
            NULL,
            3,
            NULL
        ) != pdPASS)
    {
        ESP_LOGE(
            TAG,
            "Create StorageMonitor FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "StorageMonitor created"
    );


    /* =====================================================
     * 13. TASK4 - WIFI / MQTT
     * ===================================================== */

    if (xTaskCreate(
            task4_wifi_mqtt,
            "Task4WiFi",
            4096,
            NULL,
            5,
            NULL
        ) != pdPASS)
    {
        ESP_LOGE(
            TAG,
            "Create Task4 WiFi FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "Task4 WiFi created"
    );


    /* =====================================================
     * 14. TASK5 - PUBLISH WEATHER DATA
     * ===================================================== */

    if (xTaskCreate(
            task5_publish,
            "Task5Publish",
            4096,
            NULL,
            5,
            NULL
        ) != pdPASS)
    {
        ESP_LOGE(
            TAG,
            "Create Task5 FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "Task5 created"
    );


    /* =====================================================
     * 15. TASK6 - MQTT CHECK / RESET
     * ===================================================== */

    if (xTaskCreate(
            task6_task,
            "Task6",
            4096,
            NULL,
            5,
            NULL
        ) != pdPASS)
    {
        ESP_LOGE(
            TAG,
            "Create Task6 FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "Task6 created"
    );


    /* =====================================================
     * 16. START MQTT
     * ===================================================== */

    ESP_LOGI(
        TAG,
        "Starting MQTT..."
    );

    if (wifi_mqtt_start() != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "MQTT start FAILED"
        );

        return;
    }

    ESP_LOGI(
        TAG,
        "MQTT client started"
    );


    /* =====================================================
     * 17. MAIN TASK GIỮ SỐNG
     * ===================================================== */

    while (1)
    {
        vTaskDelay(
            pdMS_TO_TICKS(1000)
        );
    }
}
