#include "wind.h" 
 
#include <stdint.h> 
#include <stdbool.h> 
 
#include "freertos/FreeRTOS.h" 
#include "freertos/portmacro.h" 
 
#include "driver/gpio.h" 
#include "esp_attr.h" 
#include "esp_err.h" 
 
 
/* ========================================================= 
 * CONFIG 
 * ========================================================= */ 
 
#define WIND_GPIO                       GPIO_NUM_14 
 
/* 
 * SparkFun Weather Meter: 
 * 1 count/second = 2.4 km/h 
 */ 
#define WIND_KPH_PER_COUNT_PER_SEC      2.4f 
 
/* 
 * Một chu kỳ đo = 5 phút 
 */ 
#define WIND_MEASUREMENT_PERIOD_SEC     300.0f 
 
/* 
 * Đếm cả rising + falling edge 
 */ 
#define WIND_EDGE_DIVIDER               2.0f 
 
 
/* ========================================================= 
 * VARIABLES 
 * ========================================================= */ 
 
static volatile uint32_t wind_count = 0; 
 
static bool wind_initialized = false; 
 
 
/* ========================================================= 
 * ISR 
 * ========================================================= */ 
 
static void IRAM_ATTR wind_isr_handler(void *arg) 
{ 
    (void)arg; 
 
    wind_count++; 
} 
 
 
/* ========================================================= 
 * INIT 
 * ========================================================= */ 
 
esp_err_t wind_init(void) 
{ 
    if (wind_initialized) 
    { 
        return ESP_OK; 
    } 
 
 
    gpio_config_t io_conf = { 
        .pin_bit_mask = (1ULL << WIND_GPIO), 
 
        .mode = GPIO_MODE_INPUT, 
 
        .pull_up_en = GPIO_PULLUP_ENABLE, 
 
        .pull_down_en = GPIO_PULLDOWN_DISABLE, 
 
        /* 
         * Đếm cả rising + falling 
         */ 
        .intr_type = GPIO_INTR_ANYEDGE 
    }; 
 
 
    esp_err_t ret = gpio_config(&io_conf); 
 
    if (ret != ESP_OK) 
    { 
        return ret; 
    } 
 
 
    /* 
     * GPIO ISR service dùng chung với rain. 
     */ 
    ret = gpio_install_isr_service(0); 
	printf("AFTER install ISR: ret=%d\n", ret); 
    if (ret != ESP_OK && 
        ret != ESP_FAIL) 
    { 
        return ret; 
    } 
 
 
    /* 
     * Đăng ký ISR cho wind 
     */ 
    ret = gpio_isr_handler_add( 
        WIND_GPIO, 
        wind_isr_handler, 
        NULL 
    ); 
 
    if (ret != ESP_OK) 
    { 
        return ret; 
    } 
 
 
    /* 
     * Reset counter 
     */ 
    portENTER_CRITICAL(); 
 
    wind_count = 0; 
 
    portEXIT_CRITICAL(); 
 
 
    wind_initialized = true; 
 
    return ESP_OK; 
} 
 
 
/* ========================================================= 
 * RESET 
 * ========================================================= */ 
 
esp_err_t wind_reset(void) 
{ 
    /* 
     * Xóa ISR 
     */ 
    if (wind_initialized) 
    { 
        esp_err_t ret = 
            gpio_isr_handler_remove(WIND_GPIO); 
 
        if (ret != ESP_OK) 
        { 
            return ret; 
        } 
    } 
 
 
    /* 
     * Xóa counter 
     */ 
    portENTER_CRITICAL(); 
 
    wind_count = 0; 
 
    portEXIT_CRITICAL(); 
 
 
    /* 
     * Không init lại ở đây. 
     */ 
    wind_initialized = false; 
 
 
    return ESP_OK; 
} 
 
 
/* ========================================================= 
 * READ WIND 
 * ========================================================= */ 
 
esp_err_t readwind(float *wind_speed_kph) 
{ 
    if (wind_speed_kph == NULL) 
    { 
        return ESP_ERR_INVALID_ARG; 
    } 
 
 
    /* 
     * Không tự init. 
     */ 
    if (!wind_initialized) 
    { 
        *wind_speed_kph = -1.0f; 
 
        return ESP_ERR_INVALID_STATE; 
    } 
 
 
    uint32_t count; 
 
 
    /* 
     * Lấy số xung trong 5 phút 
     * rồi reset counter. 
     */ 
    portENTER_CRITICAL(); 
 
    count = wind_count; 
 
    wind_count = 0; 
 
    portEXIT_CRITICAL(); 
 
 
    /* 
     * count / 300 
     *      -> count / second 
     * 
     * × 2.4 
     *      -> km/h 
     * 
     * / 2 
     *      -> vì đếm rising + falling
     * /3.6 m/s      
     */ 
    *wind_speed_kph = 
        (((float)count / WIND_MEASUREMENT_PERIOD_SEC) 
        * WIND_KPH_PER_COUNT_PER_SEC 
        / WIND_EDGE_DIVIDER)/ 3.6f; 
 
 
    return ESP_OK; 
}  
