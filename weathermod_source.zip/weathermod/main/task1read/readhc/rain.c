#include "rain.h"

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "driver/gpio.h"
#include "esp_attr.h"
#include "esp_err.h"


/* =========================================================
 * CONFIG
 * ========================================================= */

#define RAIN_GPIO              GPIO_NUM_13

/* 1 lần gàu lật = 0.2794 mm */
#define RAIN_MM_PER_TIP        0.2794f

/*
 * Thời gian chống dội (ms).
 * Gàu lật cần khoảng 100-500 ms, KHÔNG phải 5 ms như bản cũ.
 */
#define RAIN_DEBOUNCE_MS       200

/*
 * 1 = debounce trong ISR bằng tick FreeRTOS
 * 0 = ISR chỉ đếm xung (dùng để test xem lỗi có phải do ISR không)
 */
#define RAIN_ISR_DEBOUNCE      1


/* =========================================================
 * VARIABLES
 * ========================================================= */

static volatile uint32_t rain_count = 0;

#if RAIN_ISR_DEBOUNCE
/* uint32_t để đọc/ghi atomic trên CPU 32-bit */
static volatile uint32_t last_rain_tick = 0;
static volatile bool     rain_first_tip = true;
#endif

static bool rain_initialized = false;


/* =========================================================
 * ISR
 *
 * Quy tắc: chỉ dùng biến static và hàm nằm trong IRAM.
 * KHÔNG gọi esp_timer_get_time(), printf, ESP_LOG...
 * ========================================================= */

static void IRAM_ATTR rain_isr_handler(void *arg)
{
    (void)arg;

#if RAIN_ISR_DEBOUNCE
    uint32_t now = (uint32_t)xTaskGetTickCountFromISR();

    if (!rain_first_tip &&
        (uint32_t)(now - last_rain_tick) < pdMS_TO_TICKS(RAIN_DEBOUNCE_MS))
    {
        return;
    }

    rain_first_tip = false;
    last_rain_tick = now;
#endif

    rain_count++;
}


/* =========================================================
 * INIT
 * ========================================================= */
/*
esp_err_t rain_init(void){
	gpio_config_t io = {
        .pin_bit_mask = (1ULL << GPIO_NUM_12),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&io);

    int last = gpio_get_level(GPIO_NUM_12);
    int edges = 0;
    for (int i = 0; i < 100000; i++) {          // ~ vài chục ms
        int now = gpio_get_level(GPIO_NUM_12);
        if (now != last) { edges++; last = now; }
    }
    ets_printf("GPIO12 level=%d edges=%d\n", last, edges);
	return ESP_OK;
}
*/
esp_err_t rain_init(void)
{
	
    if (rain_initialized)
    {
        return ESP_OK;
    }

    esp_err_t ret;

    /*
     * 1. Cài ISR service TRƯỚC.
     *    ESP_FAIL = service đã được cài (ví dụ bởi wind) -> không phải lỗi.
     */
    ret = gpio_install_isr_service(0);

    if (ret != ESP_OK && ret != ESP_FAIL)
    {
        return ret;
    }

    /*
     * 2. Cấu hình chân với ngắt TẮT.
     */
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << RAIN_GPIO),
        .mode         = GPIO_MODE_INPUT,
        .pull_up_en   = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE
    };

    ret = gpio_config(&io_conf);

    if (ret != ESP_OK)
    {
        return ret;
    }

    /*
     * 3. Reset counter trước khi bật ngắt.
     */
    portENTER_CRITICAL();

    rain_count = 0;
#if RAIN_ISR_DEBOUNCE
    last_rain_tick = 0;
    rain_first_tip = true;
#endif

    portEXIT_CRITICAL();

    /*
     * 4. Đăng ký handler.
     */
    ret = gpio_isr_handler_add(RAIN_GPIO, rain_isr_handler, NULL);

    if (ret != ESP_OK)
    {
        return ret;
    }

    /*
     * 5. Cuối cùng mới bật ngắt cạnh lên.
     */
    ret = gpio_set_intr_type(RAIN_GPIO, GPIO_INTR_POSEDGE);

    if (ret != ESP_OK)
    {
        gpio_isr_handler_remove(RAIN_GPIO);
        return ret;
    }

    rain_initialized = true;

    return ESP_OK;

}


/* =========================================================
 * RESET
 * ========================================================= */

esp_err_t rain_reset(void)
{
    if (rain_initialized)
    {
        /* Tắt ngắt trước, rồi mới gỡ handler */
        gpio_set_intr_type(RAIN_GPIO, GPIO_INTR_DISABLE);

        esp_err_t ret = gpio_isr_handler_remove(RAIN_GPIO);

        if (ret != ESP_OK)
        {
            return ret;
        }
    }

    portENTER_CRITICAL();

    rain_count = 0;
#if RAIN_ISR_DEBOUNCE
    last_rain_tick = 0;
    rain_first_tip = true;
#endif

    portEXIT_CRITICAL();

    /* Không gọi rain_init() ở đây; sensor_init() sẽ gọi lại */
    rain_initialized = false;

    return ESP_OK;
}


/* =========================================================
 * READ RAIN
 * ========================================================= */

esp_err_t readrain(float *rain_mm)
{
    if (rain_mm == NULL)
    {
        return ESP_ERR_INVALID_ARG;
    }

    if (!rain_initialized)
    {
        *rain_mm = -1.0f;

        return ESP_ERR_INVALID_STATE;
    }

    uint32_t count;

    /* Lấy counter và reset cho chu kỳ 5 phút tiếp theo */
    portENTER_CRITICAL();

    count = rain_count;
    rain_count = 0;

    portEXIT_CRITICAL();

    *rain_mm = (float)count * RAIN_MM_PER_TIP;

    return ESP_OK;
}
