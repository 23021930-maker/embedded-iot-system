#include "rain.h" 
 
#include <stdint.h> 
#include <stdbool.h> 
 
#include "freertos/FreeRTOS.h" 
#include "freertos/portmacro.h" 
 
#include "driver/gpio.h" 
#include "esp_attr.h" 
#include "esp_err.h" 
#include "esp_timer.h" 
 
 
/* ========================================================= 
 * CONFIG 
 * ========================================================= */ 
 
#define RAIN_GPIO              GPIO_NUM_12 
 
/* 1 lần gàu lật = 0.2794 mm */ 
#define RAIN_MM_PER_TIP        0.2794f 
 
/* Không cho phép 2 lần lật cách nhau < 1 giây */ 
#define RAIN_MIN_INTERVAL_US   5000LL 
 
 
/* ========================================================= 
 * VARIABLES 
 * ========================================================= */ 
 
static volatile uint32_t rain_count = 0; 
 
static volatile int64_t last_rain_time_us = 0; 
 
static bool rain_initialized = false; 
 
 
/* ========================================================= 
 * ISR 
 * ========================================================= */ 
 
static void IRAM_ATTR rain_isr_handler(void *arg) 
{ 
    (void)arg; 
 
    int64_t now = esp_timer_get_time(); 
 
    if (last_rain_time_us != 0 && 
        (now - last_rain_time_us) < RAIN_MIN_INTERVAL_US) 
    { 
        return; 
    } 
 
    rain_count++; 
 
    last_rain_time_us = now; 
} 
 
 
/* ========================================================= 
 * INIT 
 * ========================================================= */ 
 
esp_err_t rain_init(void) 
{ 
    if (rain_initialized) 
    { 
        return ESP_OK; 
    } 
 
    gpio_config_t io_conf = { 
        .pin_bit_mask = (1ULL << RAIN_GPIO), 
        .mode = GPIO_MODE_INPUT, 
        .pull_up_en = GPIO_PULLUP_ENABLE, 
        .pull_down_en = GPIO_PULLDOWN_DISABLE, 
        .intr_type = GPIO_INTR_POSEDGE 
    }; 
 
 
    esp_err_t ret = gpio_config(&io_conf); 
 
    if (ret != ESP_OK) 
    { 
        return ret; 
    } 
 
 
    /* 
     * GPIO ISR service là service dùng chung. 
     * 
     * Nếu đã được sensor khác cài thì 
     * ESP_ERR_INVALID_STATE không phải lỗi. 
     */ 
    ret = gpio_install_isr_service(0); 
    printf("AFTER install ISR: ret=%d\n", ret); 
//printf("ESP_OK=%d\n", ESP_OK); 
//printf("ESP_FAIL=%d\n", ESP_FAIL); 
//printf("ESP_ERR_INVALID_STATE=%d\n", ESP_ERR_INVALID_STATE); 
   // if(ret == ESP_ERR_INVALID_STATE || 
     //   ret == ESP_FAIL){ 
    //isr service already installed 
       //     ret = ESP_OK;} 
    if (ret != ESP_OK && ret != ESP_FAIL) 
    { 
        return ret; 
    } 
 
 
    /* 
     * Đăng ký ISR cho rain 
     */ 
    ret = gpio_isr_handler_add( 
        RAIN_GPIO, 
        rain_isr_handler, 
        NULL 
    ); 
 
    if (ret != ESP_OK) 
    { 
        return ret; 
    } 
 
 
    /* 
     * Reset counter khi bắt đầu một chu kỳ mới 
     */ 
    portENTER_CRITICAL(); 
 
    rain_count = 0; 
    last_rain_time_us = 0; 
 
    portEXIT_CRITICAL(); 
 
 
    rain_initialized = true; 
 
    return ESP_OK; 
} 
 
 
/* ========================================================= 
 * RESET 
 * ========================================================= */ 
 
esp_err_t rain_reset(void) 
{ 
    /* 
     * Nếu đang init thì xóa ISR 
     */ 
    if (rain_initialized) 
    { 
        esp_err_t ret = 
            gpio_isr_handler_remove(RAIN_GPIO); 
 
        if (ret != ESP_OK) 
        { 
            return ret; 
        } 
    } 
 
 
    /* 
     * Xóa counter 
     */ 
    portENTER_CRITICAL(); 
 
    rain_count = 0; 
    last_rain_time_us = 0; 
 
    portEXIT_CRITICAL(); 
 
 
    /* 
     * Đánh dấu chưa init. 
     * 
     * KHÔNG gọi rain_init() ở đây. 
     * 
     * sensor_task sẽ gọi: 
     * 
     * sensor_reset() 
     *       ↓ 
     * sensor_init() 
     */ 
    rain_initialized = false; 
 
 
    return ESP_OK; 
} 
 
 
/* ========================================================= 
 * READ RAIN 
 * ========================================================= */ 
 
esp_err_t readrain(float *rain_mm) 
{ 
    if (rain_mm == NULL) 
    { 
        return ESP_ERR_INVALID_ARG; 
    } 
 
 
    /* 
     * readrain() KHÔNG init sensor. 
     * 
     * sensor_init() phải được gọi trước. 
     */ 
    if (!rain_initialized) 
    { 
        *rain_mm = -1.0f; 
 
        return ESP_ERR_INVALID_STATE; 
    } 
 
 
    uint32_t count; 
 
 
    /* 
     * Lấy counter và reset ngay lập tức. 
     * 
     * Sau lệnh này, chu kỳ 5 phút tiếp theo 
     * bắt đầu đếm lại từ 0. 
     */ 
    portENTER_CRITICAL(); 
 
    count = rain_count; 
 
    rain_count = 0; 
 
    portEXIT_CRITICAL(); 
 
 
    /* 
     * Tổng lượng mưa: 
     * 
     * rain = số lần gàu lật × 0.2794 
     */ 
    *rain_mm = 
        (float)count * RAIN_MM_PER_TIP; 
 
 
    return ESP_OK; 
}     
