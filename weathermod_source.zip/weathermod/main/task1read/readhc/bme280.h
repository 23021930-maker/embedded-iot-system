#ifndef BME280_H
#define BME280_H

#include "esp_err.h"


/*
 * Khởi tạo BME280:
 * - I2C
 * - kiểm tra ID
 * - calibration
 * - configuration
 */
esp_err_t bme280_init_sensor(void);


/*
 * Chỉ đọc:
 * - temperature
 * - humidity
 */
esp_err_t readbme280(float *temperature,
                     float *humidity);


/*
 * Xóa trạng thái BME280:
 * - delete I2C driver
 * - reset init flags
 */
esp_err_t bme280_reset(void);

#endif
