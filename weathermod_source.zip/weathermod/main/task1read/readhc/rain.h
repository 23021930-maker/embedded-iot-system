#ifndef RAIN_H
#define RAIN_H

#include "esp_err.h"

esp_err_t rain_init(void);

esp_err_t rain_reset(void);

esp_err_t readrain(float *rain_mm);

#endif
