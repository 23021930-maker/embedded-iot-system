#include "rad.h"

#include <math.h>
#include <time.h>
#include <stdint.h>

#define PI      3.14159265358979323846
#define GSC     0.0820       // MJ/m2/min

/* Hòa Lạc */
#define LATITUDE    21.01
#define LONGITUDE   105.53

/* GMT+7 */
#define UTC_OFFSET  (7 * 3600)


static double deg_to_rad(double deg)
{
    return deg * PI / 180.0;
}


esp_err_t readrad(uint32_t timestamp, float *radiation)
{
    if (radiation == NULL)
        return ESP_ERR_INVALID_ARG;

    /*
     * Unix time -> giờ địa phương Hòa Lạc
     */
    time_t local_timestamp =
        (time_t)timestamp + UTC_OFFSET;

    /*
     * Vì local_timestamp đã cộng GMT+7,
     * dùng gmtime để lấy giờ địa phương.
     */
    struct tm tm_local;

    gmtime_r(&local_timestamp, &tm_local);


    /*
     * Ngày thứ J trong năm
     *
     * tm_yday:
     * 0 = ngày 1
     */
    int J = tm_local.tm_yday + 1;


    /*
     * Thời gian bắt đầu của khoảng 5 phút
     *
     * Ví dụ:
     *
     * timestamp = 14:00:00
     *
     * khoảng tính:
     * 14:00 -> 14:05
     */
    double start_hour =
        tm_local.tm_hour
        + tm_local.tm_min / 60.0;


    /*
     * Midpoint của khoảng 5 phút
     *
     * 14:00 -> 14:05
     * midpoint = 14:02:30
     */
    double t_mid =
        start_hour + 2.5 / 60.0;


    /*
     * =========================
     * dr
     * =========================
     */

    double dr =
        1.0 +
        0.033 *
        cos(
            (2.0 * PI * J) / 365.0
        );


    /*
     * =========================
     * Solar declination
     * =========================
     */

    double delta =
        0.409 *
        sin(
            (2.0 * PI * J) / 365.0
            - 1.39
        );


    /*
     * =========================
     * Seasonal correction
     * =========================
     */

    double b =
        (2.0 * PI * (J - 81))
        / 364.0;

    double Sc =
        0.1645 * sin(2.0 * b)
        - 0.1255 * cos(b)
        - 0.0250 * sin(b);


    /*
     * =========================
     * Longitude
     * =========================
     *
     * FAO-56 dùng longitude phía Tây
     * Greenwich.
     *
     * Hòa Lạc:
     * 105.53° E
     *
     * => -105.53°
     */

    double Lm = -LONGITUDE;

    /*
     * Kinh tuyến trung tâm GMT+7:
     * 7 × 15 = 105°
     *
     * FAO-56 quy ước phía Tây:
     * => -105°
     */

    double Lz = -105.0;


    /*
     * =========================
     * Solar hour angle
     * =========================
     */

    double omega =
        (PI / 12.0)
        *
        (
            t_mid
            + 0.06667 * (Lz - Lm)
            + Sc
        )
        - PI;


    /*
     * =========================
     * Latitude
     * =========================
     */

    double phi =
        deg_to_rad(LATITUDE);


    /*
     * =========================
     * Sunset hour angle
     * =========================
     */

    double omega_s =
        acos(
            -tan(phi) * tan(delta)
        );


    /*
     * =========================
     * Khoảng 5 phút
     * =========================
     */

    double period_hour =
        5.0 / 60.0;

    double omega1 =
        omega -
        (PI / 24.0) * period_hour;

    double omega2 =
        omega +
        (PI / 24.0) * period_hour;


    /*
     * =========================
     * Mặt trời dưới chân trời
     * =========================
     */

    if (
        omega2 <= -omega_s ||
        omega1 >= omega_s
    )
    {
        *radiation = 0.0f;
        return ESP_OK;
    }


    /*
     * =========================
     * Giới hạn góc
     * =========================
     */

    if (omega1 < -omega_s)
        omega1 = -omega_s;

    if (omega2 > omega_s)
        omega2 = omega_s;


    /*
     * =========================
     * Tính Ra
     * =========================
     */

    double Ra =
        (12.0 * 60.0 / PI)
        * GSC
        * dr
        *
        (
            (omega2 - omega1)
            * sin(phi)
            * sin(delta)

            +

            cos(phi)
            * cos(delta)
            *
            (
                sin(omega2)
                - sin(omega1)
            )
        );


    if (Ra < 0.0)
        Ra = 0.0;


    *radiation = (float)Ra;

    return ESP_OK;
}
