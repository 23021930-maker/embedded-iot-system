#ifndef RAD_H
#define RAD_H

#include "esp_err.h"
#include <stdint.h>

/*
 * Tính bức xạ ngoài khí quyển Ra
 * cho khoảng 5 phút chứa timestamp.
 *
 * timestamp: Unix time (UTC)
 *
 * radiation:
 *     MJ/m2/5 phút
 */
esp_err_t readrad(uint32_t timestamp, float *radiation);

#endif
