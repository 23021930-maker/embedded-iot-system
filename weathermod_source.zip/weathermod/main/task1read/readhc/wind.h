#ifndef WIND_H
#define WIND_H

#include "esp_err.h"

esp_err_t wind_init(void);

esp_err_t wind_reset(void);

esp_err_t readwind(float *wind_speed_kph);

#endif
