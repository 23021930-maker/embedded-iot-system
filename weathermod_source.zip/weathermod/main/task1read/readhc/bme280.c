#include "bme280.h"

#include <stdint.h>
#include <stdbool.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "driver/i2c.h"
#include "esp_err.h"

/* =========================================================
 * I2C CONFIG
 * ========================================================= */

#define I2C_PORT            I2C_NUM_0

#define I2C_SDA_GPIO        GPIO_NUM_4
#define I2C_SCL_GPIO        GPIO_NUM_5

#define BME280_ADDR         0x76

#define BME280_ID_REG       0xD0
#define BME280_ID           0x60


/* =========================================================
 * BME280 REGISTERS
 * ========================================================= */

#define REG_CALIB_00        0x88
#define REG_CALIB_H1        0xA1
#define REG_CALIB_H2        0xE1

#define REG_CTRL_HUM        0xF2
#define REG_CONFIG          0xF5
#define REG_CTRL_MEAS       0xF4

#define REG_DATA            0xF7


/* =========================================================
 * VARIABLES
 * ========================================================= */

static bool i2c_initialized = false;
static bool bme_initialized = false;


/* =========================================================
 * CALIBRATION
 * ========================================================= */

static uint16_t dig_T1;
static int16_t  dig_T2;
static int16_t  dig_T3;

static uint16_t dig_P1;
static int16_t  dig_P2;
static int16_t  dig_P3;
static int16_t  dig_P4;
static int16_t  dig_P5;
static int16_t  dig_P6;
static int16_t  dig_P7;
static int16_t  dig_P8;
static int16_t  dig_P9;

static uint8_t  dig_H1;

static int16_t  dig_H2;
static uint8_t  dig_H3;
static int16_t  dig_H4;
static int16_t  dig_H5;
static int8_t   dig_H6;


/* =========================================================
 * t_fine
 * ========================================================= */

static int32_t t_fine;


/* =========================================================
 * I2C WRITE
 *
 * ESP8266_RTOS_SDK sử dụng command link API.
 * ========================================================= */

static esp_err_t bme280_write_byte(uint8_t reg,
                                   uint8_t value)
{
    i2c_cmd_handle_t cmd;

    cmd = i2c_cmd_link_create();

    if (cmd == NULL)
    {
        return ESP_ERR_NO_MEM;
    }

    i2c_master_start(cmd);

    i2c_master_write_byte(
        cmd,
        (BME280_ADDR << 1) | I2C_MASTER_WRITE,
        true
    );

    i2c_master_write_byte(
        cmd,
        reg,
        true
    );

    i2c_master_write_byte(
        cmd,
        value,
        true
    );

    i2c_master_stop(cmd);

    esp_err_t ret = i2c_master_cmd_begin(
        I2C_PORT,
        cmd,
        pdMS_TO_TICKS(1000)
    );

    i2c_cmd_link_delete(cmd);

    return ret;
}


/* =========================================================
 * I2C READ
 *
 * Đọc:
 *
 * START
 * slave + WRITE
 * register
 * REPEATED START
 * slave + READ
 * data
 * STOP
 * ========================================================= */

static esp_err_t bme280_read_bytes(uint8_t reg,
                                   uint8_t *data,
                                   size_t len)
{
    if (data == NULL || len == 0)
    {
        return ESP_ERR_INVALID_ARG;
    }

    i2c_cmd_handle_t cmd;

    cmd = i2c_cmd_link_create();

    if (cmd == NULL)
    {
        return ESP_ERR_NO_MEM;
    }

    i2c_master_start(cmd);

    /*
     * Slave address + WRITE
     */
    i2c_master_write_byte(
        cmd,
        (BME280_ADDR << 1) | I2C_MASTER_WRITE,
        true
    );

    /*
     * Register address
     */
    i2c_master_write_byte(
        cmd,
        reg,
        true
    );

    /*
     * Repeated START
     */
    i2c_master_start(cmd);

    /*
     * Slave address + READ
     */
    i2c_master_write_byte(
        cmd,
        (BME280_ADDR << 1) | I2C_MASTER_READ,
        true
    );

    /*
     * Đọc dữ liệu
     */
    if (len > 1)
    {
        i2c_master_read(
            cmd,
            data,
            len - 1,
            I2C_MASTER_ACK
        );
    }

    i2c_master_read_byte(
        cmd,
        &data[len - 1],
        I2C_MASTER_NACK
    );

    i2c_master_stop(cmd);

    esp_err_t ret = i2c_master_cmd_begin(
        I2C_PORT,
        cmd,
        pdMS_TO_TICKS(1000)
    );

    i2c_cmd_link_delete(cmd);

    return ret;
}


/* =========================================================
 * I2C INIT
 * ========================================================= */

static esp_err_t bme280_i2c_init(void)
{
    if (i2c_initialized)
    {
        return ESP_OK;
    }

    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,

        .sda_io_num = I2C_SDA_GPIO,

        .scl_io_num = I2C_SCL_GPIO,

        .sda_pullup_en = GPIO_PULLUP_ENABLE,

        .scl_pullup_en = GPIO_PULLUP_ENABLE,

        .clk_stretch_tick = 0
    };


    /*
     * ESP8266_RTOS_SDK:
     *
     * i2c_driver_install()
     * chỉ có:
     *
     * i2c_num
     * mode
     */

    esp_err_t ret = i2c_driver_install(
        I2C_PORT,
        I2C_MODE_MASTER
    );

    /*
     * Nếu driver đã được install rồi
     * thì vẫn cho phép tiếp tục.
     */

    if (ret != ESP_OK &&
        ret != ESP_ERR_INVALID_STATE)
    {
        return ret;
    }


    /*
     * Config GPIO và I2C
     */

    ret = i2c_param_config(
        I2C_PORT,
        &conf
    );

    if (ret != ESP_OK)
    {
        return ret;
    }


    i2c_initialized = true;

    return ESP_OK;
}


/* =========================================================
 * CHECK BME280 ID
 * ========================================================= */

static esp_err_t bme280_check(void)
{
    uint8_t id = 0;

    esp_err_t ret =
        bme280_read_bytes(
            BME280_ID_REG,
            &id,
            1
        );

    if (ret != ESP_OK)
    {
        return ret;
    }

    if (id != BME280_ID)
    {
        return ESP_ERR_NOT_FOUND;
    }

    return ESP_OK;
}


/* =========================================================
 * READ CALIBRATION
 * ========================================================= */

static esp_err_t bme280_read_calibration(void)
{
    uint8_t calib1[24];
    uint8_t calib_h1;
    uint8_t calib_h2[7];


    /*
     * Temperature + pressure calibration
     *
     * 0x88 -> 24 bytes
     */

    esp_err_t ret =
        bme280_read_bytes(
            REG_CALIB_00,
            calib1,
            24
        );

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * Humidity calibration H1
     */

    ret =
        bme280_read_bytes(
            REG_CALIB_H1,
            &calib_h1,
            1
        );

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * Humidity H2 -> H6
     */

    ret =
        bme280_read_bytes(
            REG_CALIB_H2,
            calib_h2,
            7
        );

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * ------------------------------------------------------
     * Temperature
     * ------------------------------------------------------
     */

    dig_T1 =
        (uint16_t)calib1[1] << 8 |
        calib1[0];

    dig_T2 =
        (int16_t)(
            ((uint16_t)calib1[3] << 8) |
            calib1[2]
        );

    dig_T3 =
        (int16_t)(
            ((uint16_t)calib1[5] << 8) |
            calib1[4]
        );


    /*
     * ------------------------------------------------------
     * Pressure
     * ------------------------------------------------------
     */

    dig_P1 =
        (uint16_t)calib1[7] << 8 |
        calib1[6];

    dig_P2 =
        (int16_t)(
            ((uint16_t)calib1[9] << 8) |
            calib1[8]
        );

    dig_P3 =
        (int16_t)(
            ((uint16_t)calib1[11] << 8) |
            calib1[10]
        );

    dig_P4 =
        (int16_t)(
            ((uint16_t)calib1[13] << 8) |
            calib1[12]
        );

    dig_P5 =
        (int16_t)(
            ((uint16_t)calib1[15] << 8) |
            calib1[14]
        );

    dig_P6 =
        (int16_t)(
            ((uint16_t)calib1[17] << 8) |
            calib1[16]
        );

    dig_P7 =
        (int16_t)(
            ((uint16_t)calib1[19] << 8) |
            calib1[18]
        );

    dig_P8 =
        (int16_t)(
            ((uint16_t)calib1[21] << 8) |
            calib1[20]
        );

    dig_P9 =
        (int16_t)(
            ((uint16_t)calib1[23] << 8) |
            calib1[22]
        );


    /*
     * ------------------------------------------------------
     * Humidity
     * ------------------------------------------------------
     */

    dig_H1 = calib_h1;

    dig_H2 =
        (int16_t)(
            ((uint16_t)calib_h2[1] << 8) |
            calib_h2[0]
        );

    dig_H3 =
        calib_h2[2];

    dig_H4 =
        (int16_t)(
            ((int16_t)calib_h2[3] << 4) |
            (calib_h2[4] & 0x0F)
        );

    dig_H5 =
        (int16_t)(
            ((int16_t)calib_h2[5] << 4) |
            ((calib_h2[4] >> 4) & 0x0F)
        );

    dig_H6 =
        (int8_t)calib_h2[6];

    return ESP_OK;
}


/* =========================================================
 * BME CONFIG
 * ========================================================= */

static esp_err_t bme280_config(void)
{
    esp_err_t ret;


    /*
     * Humidity oversampling x1
     */

    ret =
        bme280_write_byte(
            REG_CTRL_HUM,
            0x01
        );

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * Config:
     *
     * standby = 1000 ms
     * filter = off
     */

    ret =
        bme280_write_byte(
            REG_CONFIG,
            0xA0
        );

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * ctrl_meas:
     *
     * temperature x2
     * pressure x2
     * normal mode
     *
     * 0x4B
     */

    ret =
        bme280_write_byte(
            REG_CTRL_MEAS,
            0x4B
        );

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * Chờ sensor ổn định
     */

    vTaskDelay(
        pdMS_TO_TICKS(100)
    );

    return ESP_OK;
}


/* =========================================================
 * INIT BME280
 * ========================================================= */

esp_err_t bme280_init_sensor(void)
{
    if (bme_initialized)
    {
        return ESP_OK;
    }


    /*
     * 1. Init I2C
     */

    esp_err_t ret =
        bme280_i2c_init();

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * 2. Check ID
     */

    ret =
        bme280_check();

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * 3. Read calibration
     */

    ret =
        bme280_read_calibration();

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * 4. Config BME280
     */

    ret =
        bme280_config();

    if (ret != ESP_OK)
    {
        return ret;
    }


    bme_initialized = true;

    return ESP_OK;
}


/* =========================================================
 * COMPENSATE TEMPERATURE
 * ========================================================= */

static float compensate_temperature(int32_t adc_T)
{
    int32_t var1;
    int32_t var2;
    int32_t T;


    var1 =
        ((((adc_T >> 3) -
           ((int32_t)dig_T1 << 1))
         *
         ((int32_t)dig_T2))
        >> 11);


    var2 =
        (((((adc_T >> 4) -
             ((int32_t)dig_T1))
            *
            ((adc_T >> 4) -
             ((int32_t)dig_T1)))
           >> 12)
         *
         ((int32_t)dig_T3))
        >> 14;


    t_fine =
        var1 + var2;


    T =
        (t_fine * 5 + 128)
        >> 8;


    return T / 100.0f;
}


/* =========================================================
 * COMPENSATE HUMIDITY
 * ========================================================= */

static float compensate_humidity(int32_t adc_H)
{
    int32_t v_x1_u32r;


    v_x1_u32r =
        t_fine -
        ((int32_t)76800);


    v_x1_u32r =
        (((((adc_H << 14) -
             (((int32_t)dig_H4) << 20) -
             (((int32_t)dig_H5) *
              v_x1_u32r))
            +
            ((int32_t)16384))
           >> 15)
         *
         (((((((v_x1_u32r *
                ((int32_t)dig_H6))
               >> 10)
              *
              (((v_x1_u32r *
                 ((int32_t)dig_H3))
                >> 11)
               +
               ((int32_t)32768)))
             >> 10)
            +
            ((int32_t)2097152))
           *
           ((int32_t)dig_H2)
           +
           8192)
          >> 14));


    v_x1_u32r =
        v_x1_u32r -
        (((((v_x1_u32r >> 15) *
            (v_x1_u32r >> 15))
           >> 7)
          *
          ((int32_t)dig_H1))
         >> 4);


    if (v_x1_u32r < 0)
    {
        v_x1_u32r = 0;
    }


    if (v_x1_u32r > 419430400)
    {
        v_x1_u32r = 419430400;
    }


    return
        (v_x1_u32r >> 12)
        / 1024.0f;
}


/* =========================================================
 * READ RAW DATA
 * ========================================================= */

static esp_err_t bme280_read_raw(
    int32_t *adc_T,
    int32_t *adc_H)
{
    uint8_t data[8];


    if (adc_T == NULL ||
        adc_H == NULL)
    {
        return ESP_ERR_INVALID_ARG;
    }


    esp_err_t ret =
        bme280_read_bytes(
            REG_DATA,
            data,
            8
        );

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * Temperature:
     *
     * data[3] MSB
     * data[4] LSB
     * data[5] XLSB
     */

    *adc_T =
        ((int32_t)data[3] << 12) |
        ((int32_t)data[4] << 4) |
        ((int32_t)data[5] >> 4);


    /*
     * Humidity:
     *
     * data[6] MSB
     * data[7] LSB
     */

    *adc_H =
        ((int32_t)data[6] << 8) |
        data[7];


    return ESP_OK;
}


/* =========================================================
 * READ BME280
 * ========================================================= */

esp_err_t readbme280(float *temperature,
                     float *humidity)
{
    if (temperature == NULL ||
        humidity == NULL)
    {
        return ESP_ERR_INVALID_ARG;
    }


    /*
     * Giá trị mặc định khi lỗi
     */

    *temperature = -1.0f;
    *humidity = -1.0f;


    /*
     * Không tự init.
     */

    if (!bme_initialized)
    {
        return ESP_ERR_INVALID_STATE;
    }


    int32_t adc_T;
    int32_t adc_H;


    /*
     * Đọc raw
     */

    esp_err_t ret =
        bme280_read_raw(
            &adc_T,
            &adc_H
        );

    if (ret != ESP_OK)
    {
        return ret;
    }


    /*
     * Compensation
     */

    *temperature =
        compensate_temperature(adc_T);

    *humidity =
        compensate_humidity(adc_H);


    return ESP_OK;
}


/* =========================================================
 * RESET BME280
 * ========================================================= */

esp_err_t bme280_reset(void)
{
    /*
     * BME không còn initialized
     */

    bme_initialized = false;


    /*
     * Xóa I2C driver.
     *
     * sensor_init() lần sau sẽ
     * cài lại driver.
     */

    if (i2c_initialized)
    {
        esp_err_t ret =
            i2c_driver_delete(I2C_PORT);

        /*
         * Nếu driver đã bị xóa rồi
         * thì coi như reset thành công.
         */

        if (ret != ESP_OK &&
            ret != ESP_ERR_INVALID_STATE)
        {
            return ret;
        }

        i2c_initialized = false;
    }


    return ESP_OK;
}
