#ifndef SENSOR_H
#define SENSOR_H

#include <stdint.h>
#include "esp_err.h"

typedef struct
{
    uint32_t timestamp;

    float radiation;
    float rain;
    float humidity;
    float temperature;
    float windspeed;

} weather_data_t;


/* Khởi tạo toàn bộ cảm biến */
esp_err_t sensor_init(void);

/* Reset toàn bộ cảm biến */
esp_err_t sensor_reset(void);

/* Đọc tất cả cảm biến */
esp_err_t read_weather(uint32_t timestamp,
                       weather_data_t *data);

#endif
