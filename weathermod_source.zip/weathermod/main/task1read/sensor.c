#include "sensor.h"
#include <stdbool.h>
#include "bme280.h"
#include "rain.h"
#include "wind.h"
#include "rad.h"
#include <stdio.h>

/* =========================================================
 * SENSOR INIT
 * ========================================================= */

/*
esp_err_t sensor_init(void)
{
    esp_err_t ret;


    printf("SENSOR INIT: BME280...\n");

    ret = bme280_init_sensor();

    printf(
        "SENSOR INIT: BME280 ret = %d\n",
        ret
    );

    if (ret != ESP_OK)
    {
        return ret;
    }


    printf("SENSOR INIT: RAIN...\n");

    ret = rain_init();

    printf(
        "SENSOR INIT: RAIN ret = %d\n",
        ret
    );

    if (ret != ESP_OK)
    {
        return ret;
    }


    printf("SENSOR INIT: WIND...\n");

    ret = wind_init();

    printf(
        "SENSOR INIT: WIND ret = %d\n",
        ret
    );

    if (ret != ESP_OK)
    {
        return ret;
    }


    printf("SENSOR INIT: ALL OK\n");

    return ESP_OK;
}
*/
esp_err_t sensor_init(void)
{
    esp_err_t ret;

    printf("SENSOR INIT: BME280...\n");

    ret = bme280_init_sensor();

    printf("SENSOR INIT: BME280 ret = %d\n", ret);


    printf("SENSOR INIT: RAIN...\n");

    ret = rain_init();

    printf("SENSOR INIT: RAIN ret = %d\n", ret);


    printf("SENSOR INIT: WIND...\n");

    ret = wind_init();

    printf("SENSOR INIT: WIND ret = %d\n", ret);


    printf("SENSOR INIT: ALL SENSOR INIT DONE\n");

    return ESP_OK;
}

/* =========================================================
 * SENSOR RESET
 * ========================================================= */

esp_err_t sensor_reset(void)
{
    esp_err_t ret;
    bool failed = false;


    ret = bme280_reset();

    if (ret != ESP_OK)
    {
        failed = true;
    }


    ret = rain_reset();

    if (ret != ESP_OK)
    {
        failed = true;
    }


    ret = wind_reset();

    if (ret != ESP_OK)
    {
        failed = true;
    }


    if (failed)
    {
        return ESP_FAIL;
    }


    return ESP_OK;
}


/* =========================================================
 * READ ALL SENSOR
 * ========================================================= */

esp_err_t read_weather(
    uint32_t timestamp,
    weather_data_t *data)
{
    if (data == NULL)
    {
        return ESP_ERR_INVALID_ARG;
    }


    data->timestamp = timestamp;


    /*
     * Radiation
     */
    if (readrad(
            timestamp,
            &data->radiation) != ESP_OK)
    {
        data->radiation = -1.0f;
    }


    /*
     * Rain
     */
    if (readrain(
            &data->rain) != ESP_OK)
    {
        data->rain = -1.0f;
    }


    /*
     * BME280
     */
    if (readbme280(
            &data->temperature,
            &data->humidity) != ESP_OK)
    {
        data->temperature = -1.0f;
        data->humidity = -1.0f;
    }


    /*
     * Wind
     */
    if (readwind(
            &data->windspeed) != ESP_OK)
    {
        data->windspeed = -1.0f;
    }


    return ESP_OK;
}
