#include "sensortask.h"

#include <stdint.h>
#include <time.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#include "sensor.h"


/* =========================================================
 * GLOBAL QUEUE
 * ========================================================= */

QueueHandle_t weather_queue = NULL;
QueueHandle_t sensor_event_queue = NULL;


/* =========================================================
 * GLOBAL RESET RESULT
 *
 * 0 = RESET FAILED / NOT COMPLETED
 * 1 = RESET SUCCESS
 * ========================================================= */

volatile uint8_t sensor_reset_result = 0;


/* =========================================================
 * REQUEST RESET
 * ========================================================= */

esp_err_t sensor_task_request_reset(void)
{
    uint8_t event = SENSOR_EVENT_RESET;

    if (sensor_event_queue == NULL)
    {
        return ESP_ERR_INVALID_STATE;
    }

    xQueueOverwrite(
        sensor_event_queue,
        &event
    );

    return ESP_OK;
}


/* =========================================================
 * SENSOR TASK
 * ========================================================= */

void sensor_task(void *pvParameters)
{
    (void)pvParameters;


    /* =====================================================
     * SENSOR INIT LẦN ĐẦU
     * ===================================================== */

    if (sensor_init() != ESP_OK)
    {
        printf("SENSOR TASK: sensor_init FAILED\n");
    }
    else
    {
        printf("SENSOR TASK: sensor_init OK\n");
    }


    /* =====================================================
     * MAIN LOOP
     * ===================================================== */

    while (1)
    {
        weather_data_t weather;


        /* =================================================
         * ĐỌC SENSOR
         * ================================================= */

        uint32_t timestamp =
            (uint32_t)time(NULL);

        if (read_weather(
                timestamp,
                &weather) == ESP_OK)
        {
            if (weather_queue != NULL)
            {
                if (xQueueSend(
                        weather_queue,
                        &weather,
                        pdMS_TO_TICKS(1000)
                    ) != pdPASS)
                {
                    printf(
                        "SENSOR TASK: weather queue FULL\n"
                    );
                }
            }
        }


        /* =================================================
         * CHỜ 5 PHÚT HOẶC RESET
         * ================================================= */

        uint8_t event;

        BaseType_t received =
            xQueueReceive(
                sensor_event_queue,
                &event,
                pdMS_TO_TICKS(5 * 60 * 1000)
            );


        /* =================================================
         * CÓ EVENT
         * ================================================= */

        if (received == pdTRUE)
        {
            if (event == SENSOR_EVENT_RESET)
            {
                printf(
                    "SENSOR TASK: RESET REQUEST\n"
                );


                /* -----------------------------------------
                 * MẶC ĐỊNH = FAIL
                 * ----------------------------------------- */

                sensor_reset_result = 0;


                /* -----------------------------------------
                 * RESET SENSOR
                 * ----------------------------------------- */

                esp_err_t reset_ret =
                    sensor_reset();

                if (reset_ret != ESP_OK)
                {
                    printf(
                        "SENSOR TASK: sensor_reset FAILED\n"
                    );

                    sensor_reset_result = 0;

                    continue;
                }


                printf(
                    "SENSOR TASK: sensor_reset OK\n"
                );


                /* -----------------------------------------
                 * INIT LẠI SENSOR
                 * ----------------------------------------- */

                esp_err_t init_ret =
                    sensor_init();

                if (init_ret != ESP_OK)
                {
                    printf(
                        "SENSOR TASK: sensor_init FAILED\n"
                    );

                    sensor_reset_result = 0;

                    continue;
                }


                /* -----------------------------------------
                 * RESET + INIT THÀNH CÔNG
                 * ----------------------------------------- */

                printf(
                    "SENSOR TASK: sensor re-init OK\n"
                );

                sensor_reset_result = 1;
            }
        }
    }
}
