#ifndef SENSORTASK_H
#define SENSORTASK_H

#include <stdint.h>
#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"

#define SENSOR_EVENT_NORMAL 0
#define SENSOR_EVENT_RESET  1

extern QueueHandle_t weather_queue;
extern QueueHandle_t sensor_event_queue;

extern volatile uint8_t sensor_reset_result;

void sensor_task(void *pvParameters);

esp_err_t sensor_task_request_reset(void);

#endif
