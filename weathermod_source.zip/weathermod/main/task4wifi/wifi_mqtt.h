#ifndef WIFI_MQTT_H
#define WIFI_MQTT_H

#include <stdbool.h>
#include "esp_err.h"
#include "mqtt_client.h"

esp_err_t wifi_mqtt_init(void);
esp_err_t wifi_mqtt_start(void);
void task4_wifi_mqtt(void *pvParameters);
bool wifi_is_connected(void);
bool mqtt_is_connected(void);
esp_mqtt_client_handle_t get_mqtt_client(void);

#endif

