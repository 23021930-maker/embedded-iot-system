#include "wifi_mqtt.h"

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"

#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "tcpip_adapter.h"
#include "nvs_flash.h"

//static const char *WIFI_SSID     = "K_CNNN";
//static const char *WIFI_PASSWORD = "congnghenn";
//test
static const char *WIFI_SSID     = "VietLuatSu T3";
static const char *WIFI_PASSWORD = "8888@@@@";
static const char *MQTT_SERVER   = "192.168.0.188";
static const uint16_t MQTT_PORT  = 1883;
static const char *MQTT_USERNAME = "";
static const char *MQTT_PASSWORD = "";
//
//static const char *MQTT_SERVER   = "192.168.1.22";
//static const uint16_t MQTT_PORT  = 1883;
//static const char *MQTT_USERNAME = "student";
//static const char *MQTT_PASSWORD = "123456";

static const char *TAG = "TASK4";

#define WIFI_CONNECTED_BIT   BIT0
#define MQTT_CONNECTED_BIT   BIT1
#define WIFI_LOST_EVENT_BIT  BIT2
#define MQTT_LOST_EVENT_BIT  BIT3

#define TOPIC_WEATHER_ACK    "Weather/data/ACK"
#define TOPIC_PING_CHECK     "Weather/ping/check"
#define TOPIC_PING_RESET     "Weather/ping/reset"

static EventGroupHandle_t connection_event_group = NULL;
static esp_mqtt_client_handle_t mqtt_client = NULL;

static void wifi_event_handler(void *arg,
                               esp_event_base_t event_base,
                               int32_t event_id,
                               void *event_data)
{
    (void)arg;

    if (event_base == WIFI_EVENT &&
        event_id == WIFI_EVENT_STA_START)
    {
        ESP_LOGI(TAG, "WiFi started");
        esp_wifi_connect();
        return;
    }

    if (event_base == WIFI_EVENT &&
        event_id == WIFI_EVENT_STA_DISCONNECTED)
    {
        ESP_LOGW(TAG, "WiFi disconnected");

        xEventGroupClearBits(
            connection_event_group,
            WIFI_CONNECTED_BIT | MQTT_CONNECTED_BIT);

        xEventGroupSetBits(
            connection_event_group,
            WIFI_LOST_EVENT_BIT);

        return;
    }

    if (event_base == IP_EVENT &&
        event_id == IP_EVENT_STA_GOT_IP)
    {
        ip_event_got_ip_t *event =
            (ip_event_got_ip_t *)event_data;

        ESP_LOGI(TAG, "WiFi got IP: " IPSTR,
                 IP2STR(&event->ip_info.ip));

        xEventGroupSetBits(
            connection_event_group,
            WIFI_CONNECTED_BIT);
    }
}

static void mqtt_event_handler(void *handler_args,
                               esp_event_base_t base,
                               int32_t event_id,
                               void *event_data)
{
    (void)handler_args;
    (void)base;
    (void)event_data;

    switch ((esp_mqtt_event_id_t)event_id)
    {
        case MQTT_EVENT_CONNECTED:
        {
            ESP_LOGI(TAG, "MQTT connected");

            xEventGroupSetBits(
                connection_event_group,
                MQTT_CONNECTED_BIT);

            /*
             * Subscribe again after EVERY successful MQTT
             * connection. This is required because broker
             * subscriptions are not assumed to survive a
             * new MQTT session.
             */
            int id;

            id = esp_mqtt_client_subscribe(
                mqtt_client, TOPIC_WEATHER_ACK, 1);
            ESP_LOGI(TAG, "Subscribe %s -> %d",
                     TOPIC_WEATHER_ACK, id);

            id = esp_mqtt_client_subscribe(
                mqtt_client, TOPIC_PING_CHECK, 1);
            ESP_LOGI(TAG, "Subscribe %s -> %d",
                     TOPIC_PING_CHECK, id);

            id = esp_mqtt_client_subscribe(
                mqtt_client, TOPIC_PING_RESET, 1);
            ESP_LOGI(TAG, "Subscribe %s -> %d",
                     TOPIC_PING_RESET, id);

            break;
        }

        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGW(TAG, "MQTT disconnected");

            xEventGroupClearBits(
                connection_event_group,
                MQTT_CONNECTED_BIT);

            xEventGroupSetBits(
                connection_event_group,
                MQTT_LOST_EVENT_BIT);
            break;

        case MQTT_EVENT_ERROR:
            ESP_LOGE(TAG, "MQTT error");
            break;

        default:
            break;
    }
}

static esp_err_t wifi_init(void)
{
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();

    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(
        esp_event_handler_register(
            WIFI_EVENT,
            ESP_EVENT_ANY_ID,
            wifi_event_handler,
            NULL));

    ESP_ERROR_CHECK(
        esp_event_handler_register(
            IP_EVENT,
            IP_EVENT_STA_GOT_IP,
            wifi_event_handler,
            NULL));

    wifi_config_t wifi_config;
    memset(&wifi_config, 0, sizeof(wifi_config));

    strncpy((char *)wifi_config.sta.ssid,
            WIFI_SSID,
            sizeof(wifi_config.sta.ssid) - 1);

    strncpy((char *)wifi_config.sta.password,
            WIFI_PASSWORD,
            sizeof(wifi_config.sta.password) - 1);

    ESP_ERROR_CHECK(
        esp_wifi_set_mode(WIFI_MODE_STA));

    ESP_ERROR_CHECK(
        esp_wifi_set_config(
            ESP_IF_WIFI_STA,
            &wifi_config));

    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG, "WiFi initialized");
    return ESP_OK;
}

static esp_err_t mqtt_init(void)
{
    /*
     * ESP8266 RTOS SDK v3.3 / esp-mqtt supports host + port
     * configuration. No esp_netif is used here.
     */
    esp_mqtt_client_config_t mqtt_cfg = {
        .host = MQTT_SERVER,
        .port = MQTT_PORT,
        .username = MQTT_USERNAME,
        .password = MQTT_PASSWORD
    };

    mqtt_client = esp_mqtt_client_init(&mqtt_cfg);

    if (mqtt_client == NULL)
    {
        ESP_LOGE(TAG, "MQTT client init failed");
        return ESP_FAIL;
    }

    ESP_ERROR_CHECK(
        esp_mqtt_client_register_event(
            mqtt_client,
            ESP_EVENT_ANY_ID,
            mqtt_event_handler,
            NULL));

    ESP_LOGI(TAG, "MQTT initialized");
    return ESP_OK;
}

esp_err_t wifi_mqtt_init(void)
{
    esp_err_t ret;

    ret = nvs_flash_init();

    if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
        ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }

    if (ret != ESP_OK)
        return ret;

    /*
     * ESP8266 RTOS SDK v3.3 uses tcpip_adapter.
     * This must be initialized once by application code.
     */
    tcpip_adapter_init();

    ret = esp_event_loop_create_default();

    /*
     * If another component already created the default loop,
     * keep using it.
     */
    if (ret != ESP_OK && ret != ESP_ERR_INVALID_STATE)
        return ret;

    /*
     * Install the default WiFi <-> TCP/IP adapter handlers.
     */
    ret = tcpip_adapter_set_default_wifi_handlers();

    if (ret != ESP_OK && ret != ESP_ERR_INVALID_STATE)
        return ret;

    connection_event_group = xEventGroupCreate();

    if (connection_event_group == NULL)
    {
        ESP_LOGE(TAG, "Cannot create connection event group");
        return ESP_ERR_NO_MEM;
    }

    ret = wifi_init();
    if (ret != ESP_OK)
        return ret;

    ret = mqtt_init();
    if (ret != ESP_OK)
        return ret;

    /*
     * MQTT is intentionally NOT started here.
     * main.c calls wifi_mqtt_start() after Task5 has
     * registered its DATA callback.
     */
    ESP_LOGI(TAG, "WiFi + MQTT initialized");
    return ESP_OK;
}

esp_err_t wifi_mqtt_start(void)
{
    if (mqtt_client == NULL)
        return ESP_ERR_INVALID_STATE;

    ESP_LOGI(TAG, "Starting MQTT client");

    return esp_mqtt_client_start(mqtt_client);
}

void task4_wifi_mqtt(void *pvParameters)
{
    (void)pvParameters;

    ESP_LOGI(TAG, "Task 4 running");

    while (1)
    {
        EventBits_t events =
            xEventGroupWaitBits(
                connection_event_group,
                WIFI_LOST_EVENT_BIT |
                MQTT_LOST_EVENT_BIT,
                pdTRUE,
                pdFALSE,
                portMAX_DELAY);

        if (events & WIFI_LOST_EVENT_BIT)
        {
            ESP_LOGW(TAG, "Task4: reconnecting WiFi");
            esp_wifi_connect();
        }

        if (events & MQTT_LOST_EVENT_BIT)
        {
            /*
             * Do NOT stop/start MQTT here.
             * esp-mqtt handles reconnecting the existing client.
             */
            ESP_LOGW(TAG,
                     "Task4: MQTT lost; esp-mqtt will reconnect");
        }
    }
}

bool wifi_is_connected(void)
{
    if (connection_event_group == NULL)
        return false;

    return (
        xEventGroupGetBits(connection_event_group) &
        WIFI_CONNECTED_BIT) != 0;
}

bool mqtt_is_connected(void)
{
    if (connection_event_group == NULL)
        return false;

    return (
        xEventGroupGetBits(connection_event_group) &
        MQTT_CONNECTED_BIT) != 0;
}

esp_mqtt_client_handle_t get_mqtt_client(void)
{
    return mqtt_client;
}

