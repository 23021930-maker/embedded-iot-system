#ifndef TASK5_H
#define TASK5_H

#include "esp_err.h"

esp_err_t task5_init(void);
void task5_publish(void *pvParameters);

#endif

