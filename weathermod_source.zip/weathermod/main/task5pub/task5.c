#include "task5.h"

#include "storage.h"
#include "wifi_mqtt.h"
#include "task6.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "esp_log.h"
#include "mqtt_client.h"

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/semphr.h"

static const char *TAG = "TASK5";

#define WEATHER_TOPIC       "Weather/data"
#define WEATHER_ACK_TOPIC   "Weather/data/ACK"

#define MAX_BATCH_SIZE      10
#define ACK_TIMEOUT_MS      30000
#define MAX_ATTEMPTS        3

#define ACK_RECEIVED_BIT    BIT0

static EventGroupHandle_t ack_event_group = NULL;
static SemaphoreHandle_t ack_mutex = NULL;

static uint32_t ack_ids[MAX_BATCH_SIZE];
static int ack_count = 0;

/* =========================================================
 * MQTT DEBUG LOG
 * Chỉ in message, không thay đổi xử lý MQTT.
 * ========================================================= */
static void task5_print_mqtt_rx(
    esp_mqtt_event_handle_t event)
{
    if (event == NULL)
        return;

    printf("\n[TASK5] MQTT RECEIVE\n");
    printf("Topic   : ");

    if (event->topic != NULL && event->topic_len > 0)
        printf("%.*s\n", event->topic_len, event->topic);
    else
        printf("<none>\n");

    printf("Length  : %d bytes\n", event->data_len);
    printf("Payload : ");

    if (event->data != NULL && event->data_len > 0)
    {
        for (int i = 0; i < event->data_len; i++)
            printf("%02X ", (unsigned char)event->data[i]);
    }
    else
    {
        printf("<empty>");
    }

    printf("\n");
}

/*
 * This callback is registered BEFORE mqtt client start.
 * esp_mqtt_client_register_event() expects the 4-argument
 * esp_event_handler_t signature in SDK v3.3.
 */
static void task5_mqtt_event_handler(void *handler_args,
                                     esp_event_base_t base,
                                     int32_t event_id,
                                     void *event_data)
{
    (void)handler_args;
    (void)base;

    esp_mqtt_event_handle_t event =
        (esp_mqtt_event_handle_t)event_data;

    if (event == NULL)
        return;

    if ((esp_mqtt_event_id_t)event_id != MQTT_EVENT_DATA)
        return;

    /* In mọi MQTT message nhận được */
    task5_print_mqtt_rx(event);

    if (event->topic == NULL || event->topic_len <= 0)
        return;

    /*
     * Weather/ping/check and Weather/ping/reset are also
     * subscribed by Task4. Only forward them to Task6.
     */
    if (event->topic_len == (int)strlen("Weather/ping/check") &&
        strncmp(event->topic,
                "Weather/ping/check",
                event->topic_len) == 0)
    {
        ESP_LOGI(TAG, "Received Weather/ping/check");
        task6_send_command(TASK6_CMD_CHECK);
        return;
    }

    if (event->topic_len == (int)strlen("Weather/ping/reset") &&
        strncmp(event->topic,
                "Weather/ping/reset",
                event->topic_len) == 0)
    {
        ESP_LOGI(TAG, "Received Weather/ping/reset");
        task6_send_command(TASK6_CMD_RESET);
        return;
    }

    if (event->topic_len != (int)strlen(WEATHER_ACK_TOPIC) ||
        strncmp(event->topic,
                WEATHER_ACK_TOPIC,
                event->topic_len) != 0)
    {
        return;
    }

    if (event->data == NULL || event->data_len <= 0)
        return;

    char ack_payload[256];

    int len = event->data_len;
    if (len >= (int)sizeof(ack_payload))
        len = sizeof(ack_payload) - 1;

    memcpy(ack_payload, event->data, len);
    ack_payload[len] = '\0';

    ESP_LOGI(TAG, "ACK received: %s", ack_payload);

    if (ack_mutex != NULL)
        xSemaphoreTake(ack_mutex, portMAX_DELAY);

    ack_count = 0;

    char *token = strtok(ack_payload, ",");

    while (token != NULL && ack_count < MAX_BATCH_SIZE)
    {
        char *endptr = NULL;

        unsigned long id =
            strtoul(token, &endptr, 10);

        if (endptr != token)
        {
            ack_ids[ack_count++] = (uint32_t)id;
        }

        token = strtok(NULL, ",");
    }

    if (ack_mutex != NULL)
        xSemaphoreGive(ack_mutex);

    if (ack_event_group != NULL)
    {
        xEventGroupSetBits(
            ack_event_group,
            ACK_RECEIVED_BIT);
    }
}

esp_err_t task5_init(void)
{
    if (ack_event_group == NULL)
    {
        ack_event_group = xEventGroupCreate();

        if (ack_event_group == NULL)
        {
            ESP_LOGE(TAG, "Cannot create ACK event group");
            return ESP_ERR_NO_MEM;
        }
    }

    if (ack_mutex == NULL)
    {
        ack_mutex = xSemaphoreCreateMutex();

        if (ack_mutex == NULL)
        {
            ESP_LOGE(TAG, "Cannot create ACK mutex");
            return ESP_ERR_NO_MEM;
        }
    }

    esp_mqtt_client_handle_t client = get_mqtt_client();

    if (client == NULL)
    {
        ESP_LOGE(TAG,
                 "MQTT client is NULL; call wifi_mqtt_init first");
        return ESP_ERR_INVALID_STATE;
    }

    /*
     * Register BEFORE wifi_mqtt_start().
     */
    return esp_mqtt_client_register_event(
        client,
        MQTT_EVENT_ANY,
        task5_mqtt_event_handler,
        NULL);
}

static bool task5_id_in_ack(uint32_t id)
{
    bool found = false;

    if (ack_mutex != NULL)
        xSemaphoreTake(ack_mutex, portMAX_DELAY);

    for (int i = 0; i < ack_count; i++)
    {
        if (ack_ids[i] == id)
        {
            found = true;
            break;
        }
    }

    if (ack_mutex != NULL)
        xSemaphoreGive(ack_mutex);

    return found;
}

static void task5_clear_ack(void)
{
    if (ack_mutex != NULL)
        xSemaphoreTake(ack_mutex, portMAX_DELAY);

    ack_count = 0;

    if (ack_mutex != NULL)
        xSemaphoreGive(ack_mutex);

    xEventGroupClearBits(
        ack_event_group,
        ACK_RECEIVED_BIT);
}

static void task5_mark_acked(
    WeatherRecord *records,
    int count)
{
    for (int i = 0; i < count; i++)
    {
        if (!task5_id_in_ack(records[i].id))
            continue;

        uint8_t status = records[i].status;

        status |= STATUS_SENT_BIT;
        status &= (uint8_t)~STATUS_LAST_BIT;

        storage_update_status(
            records[i].id,
            status);

        records[i].status = status;

        ESP_LOGI(TAG,
                 "ID=%lu ACK -> SENT=1",
                 (unsigned long)records[i].id);
    }
}

static void task5_mark_retry(
    WeatherRecord *records,
    int count)
{
    for (int i = 0; i < count; i++)
    {
        /*
         * Already ACKed records are not retry candidates.
         */
        if (records[i].status & STATUS_SENT_BIT)
            continue;

        if (task5_id_in_ack(records[i].id))
            continue;

        uint8_t status = records[i].status;

        status |= STATUS_RETRY_BIT;
        status &= (uint8_t)~STATUS_LAST_BIT;

        storage_update_status(
            records[i].id,
            status);

        records[i].status = status;

        ESP_LOGW(TAG,
                 "ID=%lu -> RETRY=1",
                 (unsigned long)records[i].id);
    }
}

/*
 * After 3 failed attempts, mark the record as SENT so it will
 * not be selected for transmission again. It can then be
 * removed by Task3 when the SENT cleanup threshold is reached.
 */
static void task5_mark_failed(
    WeatherRecord *records,
    int count)
{
    for (int i = 0; i < count; i++)
    {
        if (records[i].status & STATUS_SENT_BIT)
            continue;

        if (task5_id_in_ack(records[i].id))
            continue;

        uint8_t status = records[i].status;

        status |= STATUS_RETRY_BIT;
        status |= STATUS_SENT_BIT;
        status &= (uint8_t)~STATUS_LAST_BIT;

        storage_update_status(
            records[i].id,
            status);

        records[i].status = status;

        ESP_LOGW(TAG,
                 "ID=%lu -> 3 attempts failed; marked SENT",
                 (unsigned long)records[i].id);
    }
}

static void task5_wait_connection(void)
{
    while (!wifi_is_connected() || !mqtt_is_connected())
    {
        ESP_LOGW(TAG, "Waiting WiFi + MQTT...");
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

/*
 * Publish only records which are still UNSENT.
 * LAST is applied only to the last record actually sent
 * in this attempt.
 */
static bool task5_publish_batch(
    WeatherRecord *records,
    int count)
{
    esp_mqtt_client_handle_t client =
        get_mqtt_client();

    if (client == NULL || !mqtt_is_connected())
        return false;

    int last_index = -1;

    for (int i = 0; i < count; i++)
    {
        if ((records[i].status & STATUS_SENT_BIT) == 0)
            last_index = i;
    }

    if (last_index < 0)
        return true;

    for (int i = 0; i < count; i++)
    {
        if (records[i].status & STATUS_SENT_BIT)
            continue;

        if (!mqtt_is_connected())
            return false;

        WeatherRecord tx_record = records[i];

        tx_record.status &= (uint8_t)~STATUS_LAST_BIT;

        if (i == last_index)
            tx_record.status |= STATUS_LAST_BIT;

        int msg_id =
            esp_mqtt_client_publish(
                client,
                WEATHER_TOPIC,
                (const char *)&tx_record,
                sizeof(WeatherRecord),
                1,
                0);

        if (msg_id < 0)
        {
            ESP_LOGE(TAG,
                     "Publish ID=%lu failed",
                     (unsigned long)tx_record.id);
            return false;
        }

        printf("\n[TASK5] MQTT SEND\n");
        printf("Topic   : %s\n", WEATHER_TOPIC);
        printf("Msg ID  : %d\n", msg_id);
        printf("Payload : WeatherRecord ID=%lu\n",
               (unsigned long)tx_record.id);
        printf("Bytes   : %u\n",
               (unsigned int)sizeof(WeatherRecord));

        ESP_LOGI(TAG,
                 "Published ID=%lu",
                 (unsigned long)tx_record.id);

        vTaskDelay(pdMS_TO_TICKS(20));
    }

    return true;
}

static bool task5_wait_ack(void)
{
    EventBits_t bits =
        xEventGroupWaitBits(
            ack_event_group,
            ACK_RECEIVED_BIT,
            pdTRUE,
            pdFALSE,
            pdMS_TO_TICKS(ACK_TIMEOUT_MS));

    if (bits & ACK_RECEIVED_BIT)
        return true;

    ESP_LOGW(TAG, "ACK timeout");
    return false;
}

static void task5_process_batch(
    WeatherRecord *records,
    int count)
{
    if (count <= 0)
        return;

    task5_clear_ack();

    for (int attempt = 1;
         attempt <= MAX_ATTEMPTS;
         attempt++)
    {
        ESP_LOGI(TAG,
                 "Attempt %d/%d",
                 attempt,
                 MAX_ATTEMPTS);

        task5_wait_connection();

        task5_clear_ack();

        bool publish_ok =
            task5_publish_batch(
                records,
                count);

        if (!publish_ok)
            ESP_LOGW(TAG, "Publish failed");

        bool ack_received =
            task5_wait_ack();

        if (ack_received)
        {
            task5_mark_acked(
                records,
                count);

            bool all_acked = true;

            for (int i = 0; i < count; i++)
            {
                if ((records[i].status & STATUS_SENT_BIT) == 0)
                {
                    all_acked = false;
                    break;
                }
            }

            if (all_acked)
            {
                ESP_LOGI(TAG, "All records ACKed");
                return;
            }

            ESP_LOGW(TAG, "Partial ACK");
        }

        if (attempt < MAX_ATTEMPTS)
        {
            task5_mark_retry(
                records,
                count);

            ESP_LOGW(TAG,
                     "Retry after 5 minutes");

            vTaskDelay(
                pdMS_TO_TICKS(5 * 60 * 1000));
        }
    }

    task5_mark_failed(
        records,
        count);

    /*
     * Avoid a tight retry loop after 3 failures.
     * The records remain UNSENT in SPIFFS.
     */
    vTaskDelay(
        pdMS_TO_TICKS(5 * 60 * 1000));
}

void task5_publish(void *pvParameters)
{
    (void)pvParameters;

    ESP_LOGI(TAG, "Task 5 started");

    while (1)
    {
        WeatherRecord records[MAX_BATCH_SIZE];

        int count =
            storage_read_unsent_batch(
                records,
                MAX_BATCH_SIZE);

        if (count <= 0)
        {
            vTaskDelay(pdMS_TO_TICKS(1000));
            continue;
        }

        ESP_LOGI(TAG,
                 "Processing batch = %d records",
                 count);

        task5_process_batch(
            records,
            count);

        vTaskDelay(pdMS_TO_TICKS(100));
    }
}
