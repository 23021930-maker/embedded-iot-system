
#include "statuscheck.h"

#include <stdbool.h>
#include <math.h>


/* =========================
 * Biến lưu trạng thái
 * ========================= */

static float last_temperature = 0.0f;
static float last_humidity = 0.0f;

static bool first_temperature = true;
static bool first_humidity = true;

static uint8_t temp_stuck_count = 0;
static uint8_t humid_stuck_count = 0;

static uint8_t rain_positive_count = 0;


/*
 * Error bị latch.
 *
 * Một khi sensor đã được đánh lỗi
 * thì tiếp tục giữ lỗi.
 */
static bool temp_error = false;
static bool humid_error = false;


/* =========================
 * Hàm statuscheck
 * ========================= */

uint8_t statuscheck(const weather_data_t *data)
{
    if (data == NULL)
        return 0xFF;


    uint8_t status = 0;

    bool rain_error = false;
    bool wind_error = false;


    /* =================================
     * RADIATION
     * =================================
     *
     * sensor.c trả về -1.0f khi đọc/tính lỗi
     * (0.0f vẫn là giá trị hợp lệ vào ban đêm).
     */

    bool rad_error = (data->radiation < 0.0f);


    /* =================================
     * RAIN
     * ================================= */

    if (data->rain < 0.0f ||
        data->rain > 10000.0f)
    {
        rain_error = true;
    }


    /* =================================
     * WIND
     * ================================= */

    if (data->windspeed < 0.0f ||
        data->windspeed > 100.0f)
    {
        wind_error = true;
    }


    /* =================================
     * HUMIDITY
     * ================================= */

    float previous_humidity = last_humidity;
    bool has_previous_humidity = !first_humidity;


    /*
     * Âm hoặc -1
     */
    if (data->humidity < 0.0f)
    {
        humid_error = true;
    }


    /*
     * >100%
     */
    if (data->humidity > 100.0f)
    {
        humid_error = true;
    }


    /*
     * Kiểm tra bị kẹt
     */
    if (has_previous_humidity)
    {
        if (fabsf(data->humidity - previous_humidity) < 0.01f)
        {
            if (humid_stuck_count < 255)
            {
                humid_stuck_count++;
            }

            if (humid_stuck_count >= 10)
            {
                humid_error = true;
            }
        }
        else
        {
            humid_stuck_count = 0;
        }
    }
    else
    {
        first_humidity = false;
    }


    /* =================================
     * TEMPERATURE
     * ================================= */

    float previous_temperature = last_temperature;
    bool has_previous_temperature = !first_temperature;


    /*
     * Âm hoặc -1
     */
    if (data->temperature < 0.0f)
    {
        temp_error = true;
    }


    /*
     * >85°C
     */
    if (data->temperature > 85.0f)
    {
        temp_error = true;
    }


    if (has_previous_temperature)
    {
        /*
         * Sensor bị kẹt
         */
        if (fabsf(data->temperature - previous_temperature) < 0.01f)
        {
            if (temp_stuck_count < 255)
            {
                temp_stuck_count++;
            }

            if (temp_stuck_count >= 10)
            {
                temp_error = true;
            }
        }
        else
        {
            temp_stuck_count = 0;
        }


        /*
         * Nhiệt độ thay đổi quá 10°C
         */
        if (fabsf(data->temperature - previous_temperature) >= 10.0f)
        {
            temp_error = true;
        }
    }
    else
    {
        first_temperature = false;
    }


    /* =================================
     * RAIN + HUMIDITY
     * ================================= */

    if (data->rain > 0.0f)
    {
        if (rain_positive_count < 255)
        {
            rain_positive_count++;
        }
    }
    else
    {
        rain_positive_count = 0;
    }


    /*
     * Mưa > 0 trong 10 lần liên tiếp
     */
    if (rain_positive_count >= 10)
    {
        /*
         * Chỉ đánh rain lỗi nếu humidity
         * hiện tại không bị lỗi.
         */
        if (!humid_error)
        {
            /*
             * Humidity không tăng
             */
            if (has_previous_humidity &&
                data->humidity <= previous_humidity)
            {
                rain_error = true;
            }
        }
    }


    /* =================================
     * LƯU GIÁ TRỊ CHO LẦN SAU
     * ================================= */

    last_temperature = data->temperature;
    last_humidity = data->humidity;


    /* =================================
     * TẠO STATUS
     * =================================
     *
     * bit 7 = RAD error
     * bit 6 = RAIN error
     * bit 5 = HUMID error
     * bit 4 = TEMP error
     * bit 3 = WIND error
     * (bit 2..0 = RETRY/LAST/SENT, gán ở storage.h / task3 / task5)
     */

    if (rad_error)
        status |= (1 << 7);

    if (rain_error)
        status |= (1 << 6);

    if (humid_error)
        status |= (1 << 5);

    if (temp_error)
        status |= (1 << 4);

    if (wind_error)
        status |= (1 << 3);


    return status;
} 
