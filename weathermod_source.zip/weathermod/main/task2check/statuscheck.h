#ifndef STATUSCHECK_H
#define STATUSCHECK_H

#include <stdint.h>
#include "sensor.h"

typedef struct
{
    float radiation;
    float rain;
    float humidity;
    float temperature;
    float windspeed;
    uint8_t status;
} processed_weather_t;

uint8_t statuscheck(const weather_data_t *data);

#endif

