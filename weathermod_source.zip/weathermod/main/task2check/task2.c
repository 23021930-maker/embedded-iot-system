#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#include "statuscheck.h"

extern QueueHandle_t weather_queue;

QueueHandle_t processed_queue = NULL;


void task2_status_check(void *pvParameters)
{
    (void)pvParameters;

    weather_data_t input;
    processed_weather_t output;

    while (1)
    {
        if (xQueueReceive(
                weather_queue,
                &input,
                portMAX_DELAY
            ) == pdTRUE)
        {
            /* Task2 kiểm tra trạng thái */
            uint8_t status =
                statuscheck(&input);

            /* Copy dữ liệu từ Task1 */
 //           output.timestamp   = input.timestamp;
            output.radiation   = input.radiation;
            output.rain        = input.rain;
            output.humidity    = input.humidity;
            output.temperature = input.temperature;
            output.windspeed   = input.windspeed;

            /* Gắn status */
            output.status = status;

            /* Gửi sang Task3 */
            if (xQueueSend(
                    processed_queue,
                    &output,
                    portMAX_DELAY
                ) != pdTRUE)
            {
                /* Queue should normally block
                   until space is available. */
            }
        }
    }
}
